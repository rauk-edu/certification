import React, { useState, useRef, useEffect } from 'react';
import { CertificateConfig, StudentData } from './types/certificate';
import { INITIAL_CONFIG, SAMPLE_STUDENTS } from './constants/defaultConfig';
import { CertificatePreview } from './components/CertificatePreview';
import { SidebarEditor } from './components/SidebarEditor';
import { TopToolbar } from './components/TopToolbar';
import { BatchTableModal } from './components/BatchTableModal';
import { PrintContainer } from './components/PrintContainer';
import { exportElementAsPng, exportElementAsPdf } from './utils/exportCertificates';
import { toKhmerDigits } from './utils/khmerNumbers';
import confetti from 'canvas-confetti';

export default function App() {
  const [config, setConfig] = useState<CertificateConfig>(() => {
    const saved = localStorage.getItem('khmer_cert_config');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        const bgUrl =
          parsed.bgUrl && parsed.bgUrl.startsWith('data:')
            ? parsed.bgUrl
            : INITIAL_CONFIG.bgUrl;

        return {
          ...INITIAL_CONFIG,
          ...parsed,
          bgUrl,
          template: {
            ...INITIAL_CONFIG.template,
            ...parsed.template,
            header: (() => {
              const savedHdr = parsed.template?.header;
              if (!savedHdr) return INITIAL_CONFIG.template.header;
              let hdr = savedHdr;
              // Clean any corrupted pattern like ប០២៦ស០២៦រ០២៦
              hdr = hdr.replace(/ប[០-៩0-9\s]*ស[០-៩0-9\s]*រ[០-៩0-9\s]*/g, 'ប.ស.រ.');

              // Ensure district office line is present if this is Banteay Meanchey / Rork primary school
              if (!hdr.includes('ការិយាល័យអប់រំ យុវជន និងកីឡាស្រុកភ្នំស្រុក') && !hdr.includes('ការិយាល័យអប់រំ')) {
                if (hdr.includes('មន្ទីរអប់រំ យុវជន និងកីឡាខេត្តបន្ទាយមានជ័យ')) {
                  hdr = hdr.replace(
                    'មន្ទីរអប់រំ យុវជន និងកីឡាខេត្តបន្ទាយមានជ័យ',
                    'មន្ទីរអប់រំ យុវជន និងកីឡាខេត្តបន្ទាយមានជ័យ\nការិយាល័យអប់រំ យុវជន និងកីឡាស្រុកភ្នំស្រុក'
                  );
                }
              }
              if (!hdr.includes('សាលាបឋមសិក្សា រោគ') && !hdr.includes('{school}')) {
                if (hdr.includes('ការិយាល័យអប់រំ យុវជន និងកីឡាស្រុកភ្នំស្រុក')) {
                  hdr = hdr.replace(
                    'ការិយាល័យអប់រំ យុវជន និងកីឡាស្រុកភ្នំស្រុក',
                    'ការិយាល័យអប់រំ យុវជន និងកីឡាស្រុកភ្នំស្រុក\nសាលាបឋមសិក្សា រោគ'
                  );
                }
              }
              if (!hdr.includes('លេខ')) {
                hdr = `${hdr.trim()}\nលេខ : {certNo} ប.ស.រ.`;
              } else {
                hdr = hdr.replace(/លេខ\s*[:៖]?\s*.*$/m, 'លេខ : {certNo} ប.ស.រ.');
              }
              return hdr;
            })(),
            subtitle:
              parsed.template?.subtitle && !parsed.template.subtitle.includes('សាលាបឋមសិក្សា រោគ')
                ? INITIAL_CONFIG.template.subtitle
                : (parsed.template?.subtitle || INITIAL_CONFIG.template.subtitle),
            logoTop: null,
            showLogoTop: false,
            showTitle: parsed.template?.showTitle ?? true,
            showSubtitle: parsed.template?.showSubtitle ?? true,
            showCertNumber: parsed.template?.showCertNumber ?? true,
            lunarDate:
              parsed.template?.lunarDate ??
              (parsed.template?.datePlace
                ? parsed.template.datePlace.split('\n')[0]
                : INITIAL_CONFIG.template.lunarDate),
            solarDate:
              parsed.template?.solarDate ??
              (parsed.template?.datePlace
                ? parsed.template.datePlace.split('\n')[1] || parsed.template.datePlace.split('\n')[0]
                : INITIAL_CONFIG.template.solarDate),
            showLunarDate: parsed.template?.showLunarDate ?? true,
            showSolarDate: parsed.template?.showSolarDate ?? true,
            showQrCode: parsed.template?.showQrCode ?? true,
            qrCodeText: parsed.template?.qrCodeText || INITIAL_CONFIG.template.qrCodeText,
            qrCodePosition: parsed.template?.qrCodePosition || 'bottom-left',
            qrCodeLabel: parsed.template?.qrCodeLabel || 'ស្កេនផ្ទៀងផ្ទាត់',
            showQrCodeLabel: parsed.template?.showQrCodeLabel ?? true,
            studentIntro:
              parsed.template?.studentIntro && !parsed.template.studentIntro.includes('កើតនៅថ្ងៃទី')
                ? INITIAL_CONFIG.template.studentIntro
                : (parsed.template?.studentIntro || INITIAL_CONFIG.template.studentIntro),
            description:
              parsed.template?.description && !parsed.template.description.includes('សាលាបឋមសិក្សា')
                ? INITIAL_CONFIG.template.description
                : (parsed.template?.description || INITIAL_CONFIG.template.description),
            wishes:
              parsed.template?.wishes && !parsed.template.wishes.includes('បណ្ណសរសើរនេះប្រគល់ជូន')
                ? INITIAL_CONFIG.template.wishes
                : (parsed.template?.wishes || INITIAL_CONFIG.template.wishes),
          },
          styles: {
            ...INITIAL_CONFIG.styles,
            ...parsed.styles,
            layout: {
              paddingTop: Math.max(115, parsed.styles?.layout?.paddingTop ?? 125),
              paddingSides: parsed.styles?.layout?.paddingSides ?? 105,
              paddingBottom: parsed.styles?.layout?.paddingBottom ?? 80,
            },
            header: {
              ...INITIAL_CONFIG.styles.header,
              ...parsed.styles?.header,
              align: 'left',
              size: parsed.styles?.header?.size ? Math.min(18, parsed.styles.header.size) : 15,
              offsetY: Math.max(0, parsed.styles?.header?.offsetY ?? 0),
            },
            body: {
              ...INITIAL_CONFIG.styles.body,
              ...parsed.styles?.body,
              align: 'left',
              indent: parsed.styles?.body?.indent ?? 48,
            },
            motto: {
              ...INITIAL_CONFIG.styles.motto,
              ...parsed.styles?.motto,
              size: parsed.styles?.motto?.size ? Math.min(18, parsed.styles.motto.size) : 16,
              offsetY: Math.max(0, parsed.styles?.motto?.offsetY ?? 0),
            },
            date: {
              ...INITIAL_CONFIG.styles.date,
              ...parsed.styles?.date,
              align: parsed.styles?.date?.align || 'left',
            },
            qrCode: {
              ...INITIAL_CONFIG.styles.qrCode,
              ...parsed.styles?.qrCode,
            },
            certNumber: {
              ...INITIAL_CONFIG.styles.certNumber,
              ...parsed.styles?.certNumber,
            },
          },
        };
      } catch (e) {
        console.error('Failed to parse saved config', e);
      }
    }
    return INITIAL_CONFIG;
  });

  const [students, setStudents] = useState<StudentData[]>(() => {
    const saved = localStorage.getItem('khmer_cert_students');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length >= 40) {
          return parsed.map((std: StudentData, idx: number) => ({
            ...std,
            certNumber: std.certNumber || toKhmerDigits(String(26 + idx).padStart(3, '0')),
          }));
        }
      } catch (e) {
        console.error('Failed to parse saved students', e);
      }
    }
    return SAMPLE_STUDENTS;
  });

  const [activeStudentIndex, setActiveStudentIndex] = useState(0);
  const [scale, setScale] = useState(0.82);
  const [printMode, setPrintMode] = useState<'current' | 'all'>('current');
  const [isBatchTableOpen, setIsBatchTableOpen] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const previewRef = useRef<HTMLDivElement>(null);
  const previewContainerRef = useRef<HTMLDivElement>(null);

  // Auto-save state
  useEffect(() => {
    try {
      localStorage.setItem('khmer_cert_config', JSON.stringify(config));
    } catch (e) {
      // ignore storage quota error for base64 images
    }
  }, [config]);

  // Auto-repair any corrupted header string from existing localStorage sessions
  useEffect(() => {
    if (
      config.template?.header &&
      (/ប[០-៩0-9]/.test(config.template.header) ||
        !config.template.header.includes('{certNo}') ||
        !config.template.header.includes('ការិយាល័យអប់រំ យុវជន និងកីឡាស្រុកភ្នំស្រុក'))
    ) {
      let repaired = config.template.header
        .replace(/ប[០-៩0-9\s]*ស[០-៩0-9\s]*រ[០-៩0-9\s]*/g, 'ប.ស.រ.')
        .replace(/លេខ\s*[:៖]?\s*.*$/m, 'លេខ : {certNo} ប.ស.រ.');

      if (!repaired.includes('ការិយាល័យអប់រំ យុវជន និងកីឡាស្រុកភ្នំស្រុក')) {
        repaired = repaired.replace(
          'មន្ទីរអប់រំ យុវជន និងកីឡាខេត្តបន្ទាយមានជ័យ',
          'មន្ទីរអប់រំ យុវជន និងកីឡាខេត្តបន្ទាយមានជ័យ\nការិយាល័យអប់រំ យុវជន និងកីឡាស្រុកភ្នំស្រុក'
        );
      }

      if (repaired !== config.template.header) {
        setConfig((prev) => ({
          ...prev,
          template: {
            ...prev.template,
            header: repaired,
          },
        }));
      }
    }
  }, [config.template?.header]);

  useEffect(() => {
    try {
      localStorage.setItem('khmer_cert_students', JSON.stringify(students));
    } catch (e) {
      // ignore
    }
  }, [students]);

  // Auto adjust scale based on container width
  useEffect(() => {
    const updateScale = () => {
      if (previewContainerRef.current) {
        const containerWidth = previewContainerRef.current.clientWidth - 48; // padding
        const optimalScale = Math.min(1.05, Math.max(0.45, containerWidth / 1080));
        setScale(Number(optimalScale.toFixed(2)));
      }
    };
    updateScale();
    window.addEventListener('resize', updateScale);
    return () => window.removeEventListener('resize', updateScale);
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const handleResetToDefault = () => {
    if (window.confirm('តើអ្នកពិតជាចង់កំណត់ទិន្នន័យឡើងវិញជាលំនាំដើមមែនទេ?')) {
      setConfig(INITIAL_CONFIG);
      setStudents(SAMPLE_STUDENTS);
      setActiveStudentIndex(0);
      localStorage.removeItem('khmer_cert_config');
      localStorage.removeItem('khmer_cert_students');
      showToast('បានកំណត់ឡើងវិញជាលំនាំដើមដោយជោគជ័យ');
    }
  };

  const handleExportPng = async () => {
    if (!previewRef.current) return;
    try {
      setIsExporting(true);
      showToast('កំពុងទាញយកជារូបភាព PNG...');
      const studentName = students[activeStudentIndex]?.name || 'certificate';
      await exportElementAsPng(
        previewRef.current,
        `ប័ណ្ណសរសើរ_${studentName.replace(/\s+/g, '_')}.png`,
        2.5
      );
      confetti({ particleCount: 60, spread: 60 });
      showToast('ទាញយករូបភាព PNG បានជោគជ័យ!');
    } catch (err) {
      console.error(err);
      alert('បរាជ័យក្នុងការទាញយករូបភាព សូមព្យាយាមម្តងទៀត');
    } finally {
      setIsExporting(false);
    }
  };

  const handleExportPdf = async () => {
    if (!previewRef.current) return;
    try {
      setIsExporting(true);
      showToast('កំពុងបង្កើត និងទាញយកឯកសារ PDF A4...');
      const studentName = students[activeStudentIndex]?.name || 'certificate';
      await exportElementAsPdf(
        previewRef.current,
        `ប័ណ្ណសរសើរ_${studentName.replace(/\s+/g, '_')}.pdf`
      );
      confetti({ particleCount: 60, spread: 60 });
      showToast('ទាញយក PDF បានជោគជ័យ!');
    } catch (err) {
      console.error(err);
      alert('បរាជ័យក្នុងការទាញយក PDF សូមព្យាយាមម្តងទៀត');
    } finally {
      setIsExporting(false);
    }
  };

  const handlePrintCurrent = async () => {
    setPrintMode('current');
    if (document.fonts?.ready) {
      await document.fonts.ready;
    }
    setTimeout(() => {
      window.print();
    }, 250);
  };

  const handlePrintAll = async () => {
    setPrintMode('all');
    if (document.fonts?.ready) {
      await document.fonts.ready;
    }
    setTimeout(() => {
      window.print();
    }, 400);
  };

  const currentStudent = students[activeStudentIndex] || students[0];

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-slate-100 font-sans">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-4 right-4 z-50 bg-slate-900 text-white text-xs font-medium px-4 py-2.5 rounded-xl shadow-lg border border-slate-700 animate-in fade-in slide-in-from-top-3 flex items-center space-x-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Left Sidebar - Editor & Config */}
      <div className="no-print h-full flex flex-col z-10">
        <SidebarEditor
          config={config}
          onChangeConfig={setConfig}
          students={students}
          onChangeStudents={setStudents}
          activeStudentIndex={activeStudentIndex}
          onSelectStudent={setActiveStudentIndex}
          onResetToDefault={handleResetToDefault}
        />
      </div>

      {/* Right Canvas Area */}
      <div className="no-print flex-1 flex flex-col h-full overflow-hidden bg-slate-200/70">
        {/* Top Control Bar */}
        <TopToolbar
          students={students}
          activeStudentIndex={activeStudentIndex}
          onSelectStudent={setActiveStudentIndex}
          scale={scale}
          onChangeScale={setScale}
          onPrintCurrent={handlePrintCurrent}
          onPrintAll={handlePrintAll}
          onExportPdf={handleExportPdf}
          onExportPng={handleExportPng}
          onOpenBatchTable={() => setIsBatchTableOpen(true)}
          isExporting={isExporting}
        />

        {/* Certificate Display Board */}
        <div
          ref={previewContainerRef}
          className="flex-1 overflow-auto p-6 flex flex-col items-center justify-start relative select-none"
        >
          {/* Certificate Shadow Box */}
          <div
            className="my-auto transition-all"
            style={{
              width: `${1050 * scale}px`,
              height: `${742 * scale}px`,
            }}
          >
            <div className="shadow-2xl rounded-sm ring-1 ring-black/10 overflow-hidden bg-white">
              <CertificatePreview
                ref={previewRef}
                config={config}
                student={currentStudent}
                studentIndex={activeStudentIndex}
                scale={scale}
              />
            </div>
          </div>

          {/* Quick Helper Tip below Canvas */}
          <div className="py-2.5 flex items-center justify-center gap-3 flex-wrap text-xs">
            <span className="text-slate-500 font-medium">ស៊ុមប័ណ្ណ៖</span>
            <button
              type="button"
              onClick={() => {
                setConfig((prev) => ({ ...prev, bgUrl: INITIAL_CONFIG.bgUrl }));
                showToast('បានជ្រើសរើសស៊ុមក្រសួងអប់រំ យុវជន និងកីឡា ផ្លូវការ');
              }}
              className="px-2.5 py-1 bg-white hover:bg-amber-50 text-slate-700 hover:text-amber-900 border border-slate-300 hover:border-amber-400 rounded-md font-medium shadow-2xs transition-colors"
            >
              🏛️ ស៊ុមក្រសួងអប់រំផ្លូវការ
            </button>
            <label className="flex items-center gap-1.5 px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white rounded-md font-semibold cursor-pointer shadow-2xs transition-colors">
              <span>📤 ផ្ទុកឡើងរូបភាពស៊ុមផ្ទាល់ខ្លួន</span>
              <input
                type="file"
                accept="image/*"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const reader = new FileReader();
                    reader.onload = (event) => {
                      if (event.target?.result) {
                        setConfig((prev) => ({
                          ...prev,
                          bgUrl: event.target!.result as string,
                        }));
                        showToast('បានប្តូរស៊ុមប័ណ្ណផ្ទៃខាងក្រោយដោយជោគជ័យ!');
                      }
                    };
                    reader.readAsDataURL(file);
                  }
                }}
              />
            </label>
            <span className="text-slate-400">|</span>
            <span className="text-slate-500">ទំហំ A4 Landscape (297mm × 210mm)</span>
          </div>
        </div>
      </div>

      {/* Hidden Print Container - Rendered only when printing */}
      <PrintContainer
        config={config}
        students={students}
        printMode={printMode}
        activeStudentIndex={activeStudentIndex}
      />

      {/* Batch Student Data Modal */}
      <BatchTableModal
        isOpen={isBatchTableOpen}
        onClose={() => setIsBatchTableOpen(false)}
        students={students}
        onSave={(updated) => {
          setStudents(updated);
          if (activeStudentIndex >= updated.length) {
            setActiveStudentIndex(0);
          }
          showToast(`បានរក្សាទុកទិន្នន័យសិស្ស ${updated.length} នាក់`);
        }}
      />
    </div>
  );
}
