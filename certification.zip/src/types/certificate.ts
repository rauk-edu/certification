export interface StyleItem {
  size: number;
  font: string;
  color: string;
  offsetY: number;
  offsetX: number;
  align?: 'left' | 'center' | 'right' | 'justify';
  indent?: number;
}

export interface CertificateTemplate {
  motto: string;
  mottoDecor: string;
  header: string;
  title: string;
  subtitle: string;
  showTitle?: boolean;
  showSubtitle?: boolean;
  studentIntro: string;
  description: string;
  wishes: string;
  datePlace: string;
  lunarDate?: string;
  solarDate?: string;
  showLunarDate?: boolean;
  showSolarDate?: boolean;
  signTitleLeft: string;
  signRoleLeft: string;
  signRoleRight: string;
  signNameLeft?: string;
  signNameRight?: string;
  showLeftSign: boolean;
  showRightSign: boolean;
  showTextWatermark: boolean;
  textWatermarkContent?: string;
  logoTop: string | null;
  showLogoTop?: boolean;
  watermark: string | null;
  customLogo: string | null;
  studentPhoto: string | null;
  rankMedalImage: string | null;
  showRankMedal: boolean;
  showStamp?: boolean;
  stampImage?: string | null;
  showQrCode?: boolean;
  qrCodeText?: string;
  qrCodePosition?: 'bottom-left' | 'bottom-right' | 'bottom-center';
  qrCodeLabel?: string;
  showQrCodeLabel?: boolean;
  showCertNumber?: boolean;
}

export interface CertificateStyles {
  header: StyleItem;
  motto: StyleItem;
  title: StyleItem;
  subtitle: StyleItem;
  body: StyleItem;
  signature: StyleItem;
  date?: StyleItem;
  dataText: {
    color: string;
    bold?: boolean;
  };
  rankText: {
    color: string;
    size: number;
    bold?: boolean;
  };
  logoTop: {
    width: number;
    offsetY: number;
    offsetX: number;
  };
  watermark: {
    width: number;
    offsetY: number;
    offsetX: number;
    opacity: number;
  };
  customLogo: {
    width: number;
    offsetY: number;
    offsetX: number;
  };
  studentPhoto: {
    width: number;
    offsetY: number;
    offsetX: number;
    shape?: 'square' | 'round';
  };
  textWatermark: {
    offsetX: number;
    offsetY: number;
  };
  rankMedal: {
    width: number;
    offsetY: number;
    offsetX: number;
  };
  rankMedalText: {
    size: number;
    font: string;
    color: string;
    offsetY: number;
    offsetX: number;
  };
  certNumber?: {
    color?: string;
    bold?: boolean;
    font?: string;
    size?: number;
  };
  stamp?: {
    width: number;
    offsetY: number;
    offsetX: number;
    opacity: number;
    rotation: number;
  };
  qrCode?: {
    size: number;
    offsetY: number;
    offsetX: number;
    color?: string;
  };
  layout?: {
    paddingTop?: number;
    paddingSides?: number;
    paddingBottom?: number;
  };
}

export interface StudentData {
  id: string;
  name: string;
  gender: string;
  grade: string;
  school: string;
  rank: string;
  year: string;
  dob?: string;
  studentPhoto?: string | null;
  customNote?: string;
  certNumber?: string;
}

export interface CertificateConfig {
  template: CertificateTemplate;
  styles: CertificateStyles;
  bgUrl: string;
  bgHue: number;
  bgBrightness?: number;
  borderStyle?: 'custom_bg' | 'golden_kbach' | 'royal_blue' | 'minimal' | 'blank';
}
