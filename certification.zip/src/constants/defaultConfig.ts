import { CertificateConfig, StudentData } from '../types/certificate';
import {
  certBgImage,
  officialMoEYSBg,
  cambodiaCertFrame,
  cleanBorderImage,
  legacyBgImage,
  goldMedalImage,
  schoolStampImage,
} from '../assets';

export const BACKGROUND_PRESETS = [
  {
    id: 'moeys_official',
    name: 'ស៊ុមក្រសួងអប់រំ យុវជន និងកីឡា (ផ្លូវការ)',
    description: 'ក្បាច់មាស & ត្រាគប់ភ្លើងក្រសួងអប់រំកណ្តាល',
    url: officialMoEYSBg,
  },
  {
    id: 'cambodia_frame',
    name: 'ស៊ុមប័ណ្ណកម្ពុជាពណ៌ស្រាល',
    description: 'ក្បាច់មាស និងត្រាស្រាលសមស្របសម្រាប់បោះពុម្ព',
    url: cambodiaCertFrame,
  },
  {
    id: 'gold_kbach',
    name: 'ស៊ុមក្បាច់មាសសុទ្ធ (គ្មានត្រាកណ្តាល)',
    description: 'ក្បាច់មាសប្រណិត ផ្ទៃកណ្តាលសសុទ្ធ',
    url: cleanBorderImage,
  },
  {
    id: 'blank_white',
    name: 'ផ្ទៃសសុទ្ធ (Blank Canvas)',
    description: 'សម្រាប់ប្រើជាមួយក្រដាសប័ណ្ណសរសើរដែលមានក្បាច់ស្រាប់',
    url: '',
  },
];

export const FONT_OPTIONS = [
  { label: 'Khmer OS Muol Light / Moul (អក្សរមូល)', value: 'Khmer OS Muol Light', css: "'Khmer OS Muol Light', 'Khmer OS Muol', 'Moul', serif" },
  { label: 'Khmer OS Battambang / Battambang (អក្សរជ្រៀង/ធម្មតា)', value: 'Khmer OS Battambang', css: "'Khmer OS Battambang', 'Battambang', sans-serif" },
  { label: 'Siemreap (សៀមរាប)', value: 'Siemreap', css: "'Siemreap', 'Khmer OS Siemreap', sans-serif" },
  { label: 'Kantumruy Pro (កន្ទុំរុយ ទំនើប)', value: 'Kantumruy Pro', css: "'Kantumruy Pro', sans-serif" },
  { label: 'Koulen (គូលែន - ក្បាលធំ)', value: 'Koulen', css: "'Koulen', cursive" },
  { label: 'Moulpali (មូលបាលី)', value: 'Moulpali', css: "'Moulpali', 'Khmer OS Muol Pali', serif" },
  { label: 'Nokora (នគរ)', value: 'Nokora', css: "'Nokora', sans-serif" },
  { label: 'Preahvihear (ព្រះវិហារ)', value: 'Preahvihear', css: "'Preahvihear', cursive" }
];

export function getFontFamilyCss(fontName: string): string {
  const found = FONT_OPTIONS.find((f) => f.value === fontName);
  if (found) return found.css;
  if (fontName.toLowerCase().includes('muol') || fontName.toLowerCase().includes('moul')) {
    return "'Khmer OS Muol Light', 'Khmer OS Muol', 'Moul', serif";
  }
  return `'${fontName}', 'Khmer OS Battambang', 'Battambang', sans-serif`;
}

export const INITIAL_CONFIG: CertificateConfig = {
  template: {
    motto: "ព្រះរាជាណាចក្រកម្ពុជា\nជាតិ សាសនា ព្រះមហាក្សត្រ",
    mottoDecor: "❁❁❁&❁❁❁",
    header: "មន្ទីរអប់រំ យុវជន និងកីឡាខេត្តបន្ទាយមានជ័យ\nការិយាល័យអប់រំ យុវជន និងកីឡាស្រុកភ្នំស្រុក\nសាលាបឋមសិក្សា រោគ\nលេខ : {certNo} ប.ស.រ.",
    title: "បណ្ណសរសើរ",
    subtitle: "នាយិកាសាលាបឋមសិក្សា រោគ",
    showTitle: true,
    showSubtitle: true,
    studentIntro: "សូមសរសើរចំពោះសិស្សឈ្មោះ {name} ភេទ {gender} កើតនៅថ្ងៃទី {dob}",
    description: "រៀនថ្នាក់ទី {grade} នៃ{school} ដែលបានខិតខំរៀនសូត្រ ទទួលបានលទ្ធផលល្អក្នុងការសិក្សា និងទទួលបានចំណាត់ថ្នាក់លេខ{rank} ប្រចាំឆ្នាំសិក្សា{year} ។",
    wishes: "បណ្ណសរសើរនេះប្រគល់ជូនសាមីខ្លួនប្រើប្រាស់តាមការដែលអាចប្រើបាន។",
    datePlace: "ថ្ងៃ.....................ខែ.................. ឆ្នាំមមី អដ្ឋស័ក ព.ស.២៥៧០\n.................. ថ្ងៃទី.......... ខែ............. ឆ្នាំ២០២៦",
    lunarDate: "ថ្ងៃសុក្រ ១០កើត ខែកត្តិក ឆ្នាំម្សាញ់ សប្តស័ក ព.ស.២៥៦៩",
    solarDate: "រោគ ថ្ងៃទី ៣១ ខែតុលា ឆ្នាំ២០២៥",
    showLunarDate: true,
    showSolarDate: true,
    signTitleLeft: "បានឃើញ និងឯកភាព",
    signRoleLeft: "ប្រធានការិយាល័យ",
    signRoleRight: "នាយិកាសាលា",
    signNameRight: "",
    signNameLeft: "",
    showLeftSign: false,
    showRightSign: true,
    showTextWatermark: false,
    textWatermarkContent: "ក្រសួងអប់រំ យុវជន និងកីឡា",
    logoTop: null,
    showLogoTop: false,
    watermark: null,
    customLogo: null,
    studentPhoto: null,
    rankMedalImage: goldMedalImage,
    showRankMedal: true,
    showStamp: true,
    stampImage: schoolStampImage,
    showQrCode: true,
    qrCodeText: "https://verify.moeys.gov.kh/cert?id={id}&name={name}&rank={rank}&grade={grade}&school={school}&year={year}",
    qrCodePosition: "bottom-left",
    qrCodeLabel: "ស្កេនផ្ទៀងផ្ទាត់",
    showQrCodeLabel: true,
    showCertNumber: true,
  },
  styles: {
    layout: {
      paddingTop: 125,
      paddingSides: 105,
      paddingBottom: 80,
    },
    header: {
      size: 15,
      font: "Khmer OS Muol Light",
      color: "#000000",
      offsetY: 0,
      offsetX: 0,
      align: "left",
    },
    motto: {
      size: 16,
      font: "Khmer OS Muol Light",
      color: "#000000",
      offsetY: 0,
      offsetX: 0
    },
    title: {
      size: 38,
      font: "Khmer OS Muol Light",
      color: "#dc2626", // bold red
      offsetY: -15,
      offsetX: 0
    },
    subtitle: {
      size: 22,
      font: "Khmer OS Muol Light",
      color: "#1d4ed8", // deep royal blue
      offsetY: -20,
      offsetX: 0
    },
    body: {
      size: 19,
      font: "Khmer OS Battambang",
      color: "#111827",
      offsetY: -25,
      offsetX: 0,
      align: "left",
      indent: 48,
    },
    signature: {
      size: 18,
      font: "Khmer OS Muol Light",
      color: "#000000",
      offsetY: -15,
      offsetX: 0
    },
    date: {
      size: 14,
      font: "Khmer OS Battambang",
      color: "#1e293b",
      offsetY: 0,
      offsetX: 0,
      align: "left",
    },
    dataText: {
      color: "#1d4ed8",
      bold: true
    },
    rankText: {
      color: "#dc2626",
      size: 26,
      bold: true
    },
    logoTop: {
      width: 90,
      offsetY: 0,
      offsetX: 0
    },
    watermark: {
      width: 380,
      offsetY: 0,
      offsetX: 0,
      opacity: 0.15
    },
    customLogo: {
      width: 140,
      offsetY: 0,
      offsetX: 0
    },
    studentPhoto: {
      width: 90,
      offsetY: 0,
      offsetX: 0,
      shape: 'square'
    },
    textWatermark: {
      offsetX: 0,
      offsetY: 0
    },
    rankMedal: {
      width: 85,
      offsetY: -35,
      offsetX: -60
    },
    rankMedalText: {
      size: 38,
      font: "Khmer OS Muol Light",
      color: "#dc2626",
      offsetY: -10,
      offsetX: 0
    },
    stamp: {
      width: 120,
      offsetY: 10,
      offsetX: 20,
      opacity: 0.9,
      rotation: -8
    },
    qrCode: {
      size: 76,
      offsetY: 0,
      offsetX: 0,
      color: "#1e293b"
    },
    certNumber: {
      color: "#1d4ed8", // ពណ៌ទឹកប៊ិច (rich pen blue ink)
      bold: true,
      font: "Khmer OS Battambang"
    }
  },
  bgUrl: certBgImage,
  bgHue: 0,
  bgBrightness: 100,
  borderStyle: 'custom_bg'
};

export const SAMPLE_STUDENTS: StudentData[] = [
  { id: 'ROK-01', certNumber: '០២៦', name: 'សុង  សុជាតា', gender: 'ស្រី', dob: '15-Mar-2019', grade: '២ខ', rank: '១', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-02', certNumber: '០២៧', name: 'យឿត ឆារ៉ាយុទ្ធ', gender: 'ប្រុស', dob: '25-Dec-2018', grade: '២ខ', rank: '២', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-03', certNumber: '០២៨', name: 'ស្វាងរ៉ូ  សុធាវី', gender: 'ស្រី', dob: '12-Jun-2019', grade: '២ខ', rank: '៣', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-04', certNumber: '០២៩', name: 'សួយ ឆាយអ៊ីន', gender: 'ប្រុស', dob: '23-Jan-2019', grade: '២ខ', rank: '៤', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-05', certNumber: '០៣០', name: 'សុង ស៊ីហេង', gender: 'ស្រី', dob: '15-Jun-2019', grade: '២ខ', rank: '៤', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-06', certNumber: '០៣១', name: 'អូន ថងស៊ី', gender: 'ស្រី', dob: '4-Jul-2018', grade: '២ខ', rank: '៥', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-07', certNumber: '០៣២', name: 'ជឿន  ស៊ីថា', gender: 'ស្រី', dob: '10-Dec-2015', grade: '៥ក', rank: '១', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-08', certNumber: '០៣៣', name: 'ដឿប  ស្រីនាត', gender: 'ស្រី', dob: '24-Nov-2015', grade: '៥ក', rank: '២', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-09', certNumber: '០៣៤', name: 'លាង ដាលីន', gender: 'ស្រី', dob: '21-Jul-2016', grade: '៥ក', rank: '៣', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-10', certNumber: '០៣៥', name: 'ហែម ឡៃហ៊ាង', gender: 'ស្រី', dob: '24-Dec-2015', grade: '៥ក', rank: '៤', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-11', certNumber: '០៣៦', name: 'ដាំ វិនិត', gender: 'ស្រី', dob: '13-Nov-2014', grade: '៥ក', rank: '៥', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-12', certNumber: '០៣៧', name: 'ថុល បញ្ញា', gender: 'ស្រី', dob: '19-Dec-2017', grade: '៣ក', rank: '១', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-13', certNumber: '០៣៨', name: 'ទឹត ទេវី', gender: 'ស្រី', dob: '15-Aug-2018', grade: '៣ក', rank: '២', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-14', certNumber: '០៣៩', name: 'ឡៃ អុីឈីតាន់', gender: 'ស្រី', dob: '19-Nov-2017', grade: '៣ក', rank: '៣', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-15', certNumber: '០៤០', name: 'សារ៉ាត់ អ៊ិញប៉ាវ', gender: 'ប្រុស', dob: '8-Apr-2018', grade: '៣ក', rank: '៤', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-16', certNumber: '០៤១', name: 'ថាន់ ដាណា', gender: 'ស្រី', dob: '19-Jan-2018', grade: '៣ក', rank: '៥', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-17', certNumber: '០៤២', name: 'ស្និត ស្រីអ', gender: 'ស្រី', dob: '17-Dec-2017', grade: '៣ក', rank: '៥', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-18', certNumber: '០៤៣', name: 'ឃួញ  កែវក្លិនក្រអូប', gender: 'ស្រី', dob: '28-May-2015', grade: '៦ក', rank: '១', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-19', certNumber: '០៤៤', name: 'ឆា លីណា', gender: 'ស្រី', dob: '19-Nov-2014', grade: '៦ក', rank: '១', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-20', certNumber: '០៤៥', name: 'ប៉ុន ភិនដាវ', gender: 'ស្រី', dob: '29-Jun-2014', grade: '៦ក', rank: '៣', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-21', certNumber: '០៤៦', name: 'ជុន ចន្ទ្រា', gender: 'ស្រី', dob: '21-Aug-2014', grade: '៦ក', rank: '៤', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-22', certNumber: '០៤៧', name: 'ម៉ែត មេសា', gender: 'ស្រី', dob: '30-Apr-2015', grade: '៦ក', rank: '៥', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-23', certNumber: '០៤៨', name: 'រឿង ខេមា', gender: 'ស្រី', dob: '12-May-2014', grade: '៦ក', rank: '៥', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-24', certNumber: '០៤៩', name: 'វ៉ាន់ កញ្ចរ៉ា', gender: 'ស្រី', dob: '27-Feb-2019', grade: '២ក', rank: '១', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-25', certNumber: '០៥០', name: 'រួម រីម៉ាយ៉ា', gender: 'ស្រី', dob: '15-Jul-2018', grade: '២ក', rank: '២', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-26', certNumber: '០៥១', name: 'តោន អមរាផន', gender: 'ស្រី', dob: '8-Mar-2019', grade: '២ក', rank: '៣', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-27', certNumber: '០៥២', name: 'វ៉ាន សុផានី', gender: 'ស្រី', dob: '12-Jun-2019', grade: '២ក', rank: '៤', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-28', certNumber: '០៥៣', name: 'ស្គិន សុផា', gender: 'ស្រី', dob: '17-Apr-2019', grade: '២ក', rank: '៥', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-29', certNumber: '០៥៤', name: 'ភឿង សក្ដិក្ដា', gender: 'ប្រុស', dob: '11-Jul-2016', grade: '៤ខ', rank: '១', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-30', certNumber: '០៥៥', name: 'សុខា ផល្លី', gender: 'ស្រី', dob: '6-Jun-2016', grade: '៤ខ', rank: '២', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-31', certNumber: '០៥៦', name: 'យឿ សុផាត់', gender: 'ប្រុស', dob: '12-Sep-2014', grade: '៤ខ', rank: '៣', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-32', certNumber: '០៥៧', name: 'ធេន វណ្ណៈ', gender: 'ប្រុស', dob: '2-Aug-2016', grade: '៤ខ', rank: '៤', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-33', certNumber: '០៥៨', name: 'ឡេម ណាមវ៉ាន', gender: 'ស្រី', dob: '12-Oct-2015', grade: '៤ខ', rank: '៥', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-34', certNumber: '០៥៩', name: 'រឹត ភារុណ', gender: 'ប្រុស', dob: '29-Apr-2016', grade: '៤ខ', rank: '៥', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-35', certNumber: '០៦០', name: 'ជួយ  លីដា', gender: 'ស្រី', dob: '21-Sep-2017', grade: '3ខ', rank: '១', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-36', certNumber: '០៦១', name: 'រ៉ុង ស៊ូសានណា', gender: 'ស្រី', dob: '3-Mar-2017', grade: '3ខ', rank: '១', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-37', certNumber: '០៦២', name: 'មាន សិទ្ធិកា', gender: 'ស្រី', dob: '17-Aug-2018', grade: '3ខ', rank: '៣', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-38', certNumber: '០៦៣', name: 'វ៉ន ផល្លា', gender: 'ស្រី', dob: '5-Apr-2017', grade: '3ខ', rank: '៤', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-39', certNumber: '០៦៤', name: 'លឿត ខៅហ្វាង', gender: 'ស្រី', dob: '18-Nov-2018', grade: '3ខ', rank: '៥', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-40', certNumber: '០៦៥', name: 'ភន់  លីសា', gender: 'ស្រី', dob: '18-Jun-2015', grade: '5ខ', rank: '១', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-41', certNumber: '០៦៦', name: 'ប៉ង់ ថេវ័ន្ដ', gender: 'ប្រុស', dob: '17-Dec-2015', grade: '5ខ', rank: '២', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-42', certNumber: '០៦៧', name: 'ឆាត ឆុនដា', gender: 'ប្រុស', dob: '23-Apr-2015', grade: '5ខ', rank: '៣', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-43', certNumber: '០៦៨', name: 'ថុល ម្នីរតនា', gender: 'ប្រុស', dob: '2-Jun-2016', grade: '5ខ', rank: '៤', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-44', certNumber: '០៦៩', name: 'សម្បត្តិ សុនីកា', gender: 'ស្រី', dob: '13-Oct-2016', grade: '5ខ', rank: '៥', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-45', certNumber: '០៧០', name: 'ឃួញ  កែវម៉ូនីកា', gender: 'ស្រី', dob: '13-Dec-2016', grade: '4ក', rank: '១', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-46', certNumber: '០៧១', name: 'ឆៃ នូឌី', gender: 'ស្រី', dob: '6-Dec-2017', grade: '4ក', rank: '២', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-47', certNumber: '០៧២', name: 'សី ថាវិន', gender: 'ប្រុស', dob: '23-Dec-2017', grade: '4ក', rank: '៣', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-48', certNumber: '០៧៣', name: 'យ៉ុន សិកា', gender: 'ស្រី', dob: '18-May-2017', grade: '4ក', rank: '៤', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null },
  { id: 'ROK-49', certNumber: '០៧៤', name: 'ស្វាងរ៉ូ សុធារី', gender: 'ស្រី', dob: '28-Oct-2017', grade: '4ក', rank: '៥', school: 'សាលាបឋមសិក្សា រោគ', year: '២០២៥-២០២៦', studentPhoto: null }
];

export interface PresetTemplate {
  id: string;
  nameKhmer: string;
  description: string;
  title: string;
  subtitle: string;
  studentIntro: string;
  descriptionText: string;
  wishes: string;
  badgeLabel?: string;
}

export const PRESET_TEMPLATES: PresetTemplate[] = [
  {
    id: 'annual_honor',
    nameKhmer: '🏆 ប័ណ្ណសរសើរ ប្រចាំឆ្នាំ (ចំណាត់ថ្នាក់ប្រឡង)',
    description: 'សម្រាប់សិស្សឆ្នើមប្រចាំឆ្នាំ និងចំណាត់ថ្នាក់លេខ ១, ២, ៣...',
    title: 'បណ្ណសរសើរ',
    subtitle: 'នាយក{school}',
    studentIntro: 'សូមសរសើរចំពោះសិស្សឈ្មោះ {name} ភេទ {gender} កើតថ្ងៃទី {dob} រៀនថ្នាក់ទី {grade} នៃ{school} ដែលបានខិតខំ',
    descriptionText: 'សិក្សារៀនសូត្រទទួលបានលទ្ធផលល្អ និងទទួលបានចំណាត់ថ្នាក់លេខ{rank} ប្រចាំឆ្នាំសិក្សា{year} ។',
    wishes: 'សូមជូនពរមានសុខភាពល្អ ប្រាជ្ញាឈ្លាសវៃ សម្រេចជោគជ័យដូចបំណង ។\nប័ណ្ណសរសើរនេះប្រគល់ជូនសាមីខ្លួនប្រើប្រាស់តាមការដែលអាចប្រើបាន ។',
    badgeLabel: 'ប្រចាំឆ្នាំ'
  },
  {
    id: 'semester_honor',
    nameKhmer: '🥇 ប័ណ្ណសរសើរ ប្រចាំឆមាស',
    description: 'សម្រាប់លទ្ធផលប្រឡងឆមាសទី១ ឬ ឆមាសទី២',
    title: 'បណ្ណសរសើរ',
    subtitle: 'នាយក{school}',
    studentIntro: 'សូមសរសើរចំពោះសិស្សឈ្មោះ {name} ភេទ {gender} កើតថ្ងៃទី {dob} រៀនថ្នាក់ទី {grade} នៃ{school} ដែលបានខិតខំ',
    descriptionText: 'សិក្សារៀនសូត្រទទួលបានលទ្ធផលល្អប្រសើរ និងទទួលបានចំណាត់ថ្នាក់លេខ{rank} ប្រចាំឆមាសទី១ ឆ្នាំសិក្សា{year} ។',
    wishes: 'សូមជូនពរទទួលបានជោគជ័យក្នុងការសិក្សា និងអនាគតភ្លឺស្វាង ។\nប័ណ្ណសរសើរនេះប្រគល់ជូនសាមីខ្លួនដើម្បីជាកិត្តិយស ។',
    badgeLabel: 'ឆមាស'
  },
  {
    id: 'model_student',
    nameKhmer: '🌟 ប័ណ្ណសរសើរ សិស្សគំរូ វិន័យល្អ & សីលធម៌',
    description: 'លើកទឹកចិត្តសិស្សដែលមានចរិយាសម្បត្តិ និងសីលធម៌ល្អប្រពៃ',
    title: 'បណ្ណសរសើរ',
    subtitle: 'នាយក{school}',
    studentIntro: 'សូមសរសើរចំពោះសិស្សឈ្មោះ {name} ភេទ {gender} កើតថ្ងៃទី {dob} រៀនថ្នាក់ទី {grade} នៃ{school} ដែលជាសិស្សគំរូ',
    descriptionText: 'មានវិន័យ សីលធម៌ល្អ សិក្សាឧស្សាហ៍ព្យាយាម និងជួយសង្គមជាតិ ប្រចាំឆ្នាំសិក្សា{year} ។',
    wishes: 'សូមប្រសិទ្ធពរជ័យ សិរីមង្គល វិបុលសុខគ្រប់ប្រការ និងជោគជ័យគ្រប់ភារកិច្ច ។',
    badgeLabel: 'សិស្សគំរូ'
  },
  {
    id: 'teacher_appreciation',
    nameKhmer: '🎖️ លិខិតសរសើរ លោកគ្រូ-អ្នកគ្រូឆ្នើម',
    description: 'សម្រាប់គ្រូបង្រៀនដែលមានស្នាដៃឆ្នើមក្នុងការបង្រៀន និងអប់រំ',
    title: 'លិខិតសរសើរ',
    subtitle: 'មន្ទីរអប់រំ យុវជន និងកីឡា',
    studentIntro: 'សូមថ្លែងនូវការកោតសរសើរចំពោះ លោក/លោកស្រី {name} មុខតំណែង គ្រូបង្រៀន នៅ{school}',
    descriptionText: 'ដែលបានលះបង់កម្លាំងកាយចិត្តក្នុងការបង្រៀន និងបណ្តុះបណ្តាលសិស្សានុសិស្សទទួលបានលទ្ធផលគំរូ ប្រចាំឆ្នាំសិក្សា{year} ។',
    wishes: 'សូមជូនពរលោក/លោកស្រីជួបតែពុទ្ធពរទាំងបួនប្រការគឺ អាយុ វណ្ណៈ សុខៈ ពលៈ កុំបីឃ្លៀងឃ្លាតឡើយ ។',
    badgeLabel: 'គ្រូឆ្នើម'
  },
  {
    id: 'competition_award',
    nameKhmer: '⚽ ប័ណ្ណសរសើរ ការប្រកួតប្រជែង / កីឡា & គណិត-រូបវិទ្យា',
    description: 'សម្រាប់ជ័យលាភីការប្រកួតកីឡា ឬការប្រឡងសិស្សពូកែ',
    title: 'បណ្ណសរសើរជ័យលាភី',
    subtitle: 'គណៈកម្មការរៀបចំការប្រកួត',
    studentIntro: 'សូមសរសើរចំពោះ {name} តំណាង{school} ថ្នាក់ទី{grade}',
    descriptionText: 'ដែលបានចូលរួមប្រកួត និងដណ្តើមបានចំណាត់ថ្នាក់ជ័យលាភីលេខ{rank} ក្នុងព្រឹត្តិការណ៍ប្រកួតប្រចាំឆ្នាំសិក្សា{year} ។',
    wishes: 'សូមបន្តរក្សាស្មារតីតស៊ូ និងការខិតខំប្រឹងប្រែងដើម្បីកិត្តិយសសាលារៀន និងគ្រួសារ ។',
    badgeLabel: 'ជ័យលាភី'
  }
];
