import { StudentData } from '../types/certificate';

export const DEFAULT_QR_URL_TEMPLATE =
  'https://verify.moeys.gov.kh/cert?id={id}&name={name}&rank={rank}&grade={grade}&school={school}&year={year}';

export const DEFAULT_QR_TEXT_TEMPLATE =
  'ប័ណ្ណសរសើរផ្លូវការ - {school}\nលេខកូដ៖ {id}\nសិស្សឈ្មោះ៖ {name} (ភេទ {gender})\nថ្ងៃខែកំណើត៖ {dob}\nថ្នាក់ទី៖ {grade} | ចំណាត់ថ្នាក់៖ លេខ {rank}\nឆ្នាំសិក្សា៖ {year}';

export const DEFAULT_QR_JSON_TEMPLATE =
  '{"id":"{id}","name":"{name}","gender":"{gender}","dob":"{dob}","grade":"{grade}","rank":"{rank}","school":"{school}","year":"{year}"}';

export function generateStudentQrPayload(
  templateString: string | undefined,
  student: StudentData
): string {
  const template =
    templateString && templateString.trim() !== ''
      ? templateString
      : DEFAULT_QR_URL_TEMPLATE;

  return template
    .replace(/\{id\}/g, encodeOrRaw(student.id || '', template))
    .replace(/\{name\}/g, encodeOrRaw(student.name || '', template))
    .replace(/\{gender\}/g, encodeOrRaw(student.gender || '', template))
    .replace(/\{dob\}/g, encodeOrRaw(student.dob || '', template))
    .replace(/\{grade\}/g, encodeOrRaw(student.grade || '', template))
    .replace(/\{rank\}/g, encodeOrRaw(student.rank || '', template))
    .replace(/\{school\}/g, encodeOrRaw(student.school || '', template))
    .replace(/\{year\}/g, encodeOrRaw(student.year || '', template))
    .replace(/\{certNo\}/g, encodeOrRaw(student.certNumber || '', template))
    .replace(/\{certNumber\}/g, encodeOrRaw(student.certNumber || '', template));
}

function encodeOrRaw(val: string, template: string): string {
  // If template is a URL query string, encode value for safety
  if (template.startsWith('http://') || template.startsWith('https://')) {
    return encodeURIComponent(val.trim());
  }
  return val.trim();
}
