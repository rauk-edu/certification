import React from 'react';
import { CertificateStyles, StudentData } from '../types/certificate';
import { toKhmerDigits } from './khmerNumbers';

export function formatKhmerDob(dob?: string | null): string {
  if (!dob) return '................';
  // If format is like "15-Mar-2019" or "15/Mar/2019"
  const m = dob.match(/^(\d{1,2})[-/ ]([A-Za-z]{3})[-/ ](\d{4})$/i);
  if (m) {
    const day = toKhmerDigits(m[1].padStart(2, '0'));
    const monthMap: Record<string, string> = {
      jan: '០១', feb: '០២', mar: '០៣', apr: '០៤', may: '០៥', jun: '០៦',
      jul: '០៧', aug: '០៨', sep: '០៩', oct: '១០', nov: '១១', dec: '១២',
    };
    const month = monthMap[m[2].toLowerCase()] || m[2];
    const year = toKhmerDigits(m[3]);
    return `${day}-${month}-${year}`;
  }
  // If format is like "15-03-2019" or "15/03/2019"
  const m2 = dob.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/);
  if (m2) {
    return `${toKhmerDigits(m2[1].padStart(2, '0'))}-${toKhmerDigits(m2[2].padStart(2, '0'))}-${toKhmerDigits(m2[3])}`;
  }
  return toKhmerDigits(dob);
}

export function interpolateText(text: string, student: StudentData): string {
  if (!text) return '';
  return text
    .replace(/\{name\}/g, student.name || '.................')
    .replace(/\{gender\}/g, student.gender || '.........')
    .replace(/\{grade\}/g, student.grade || '.........')
    .replace(/\{school\}/g, student.school || '..................')
    .replace(/\{rank\}/g, student.rank || '.....')
    .replace(/\{year\}/g, student.year || '២០២៥ - ២០២៦')
    .replace(/\{dob\}/g, formatKhmerDob(student.dob))
    .replace(/\{certNo\}/g, student.certNumber || '០២៦')
    .replace(/\{certNumber\}/g, student.certNumber || '០២៦');
}

export function renderInterpolatedRichText(
  text: string,
  student: StudentData,
  styles: CertificateStyles
): React.ReactNode {
  if (!text) return null;

  // Split by placeholders
  const regex = /(\{(?:name|gender|grade|school|rank|year|dob|certNo|certNumber)\})/g;
  const parts = text.split(regex);

  return parts.map((part, index) => {
    switch (part) {
      case '{name}':
        return (
          <span
            key={index}
            className="font-bold inline whitespace-nowrap px-1"
            style={{ color: styles.dataText?.color || '#0000ff' }}
          >
            {student.name || '...................'}
          </span>
        );
      case '{gender}':
        return (
          <span
            key={index}
            className="font-semibold inline whitespace-nowrap px-1"
            style={{ color: styles.dataText?.color || '#0000ff' }}
          >
            {student.gender || '.....'}
          </span>
        );
      case '{grade}':
        return (
          <span
            key={index}
            className="font-semibold inline whitespace-nowrap px-1"
            style={{ color: styles.dataText?.color || '#0000ff' }}
          >
            {student.grade || '.....'}
          </span>
        );
      case '{school}':
        return (
          <span
            key={index}
            className="font-semibold inline whitespace-nowrap px-1"
            style={{ color: styles.dataText?.color || '#0000ff' }}
          >
            {student.school || '...................'}
          </span>
        );
      case '{rank}':
        return (
          <span
            key={index}
            className="font-bold inline whitespace-nowrap px-1.5"
            style={{
              color: styles.rankText?.color || '#ff0000',
              fontSize: styles.rankText?.size ? `${styles.rankText.size}px` : undefined,
              lineHeight: 1
            }}
          >
            {student.rank || '.....'}
          </span>
        );
      case '{year}':
        return (
          <span
            key={index}
            className="font-semibold inline whitespace-nowrap px-1"
            style={{ color: styles.dataText?.color || '#0000ff' }}
          >
            {student.year || '២០២៥ - ២០២៦'}
          </span>
        );
      case '{dob}':
        return (
          <span
            key={index}
            className="font-semibold inline whitespace-nowrap px-1"
            style={{ color: styles.dataText?.color || '#0000ff' }}
          >
            {formatKhmerDob(student.dob)}
          </span>
        );
      case '{certNo}':
      case '{certNumber}':
        return (
          <span
            key={index}
            className="font-bold inline whitespace-nowrap px-1"
            style={{ color: styles.certNumber?.color || '#1d4ed8' }}
          >
            {student.certNumber || '០២៦'}
          </span>
        );
      default:
        return <React.Fragment key={index}>{part}</React.Fragment>;
    }
  });
}
