import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';

interface StudentQRCodeProps {
  value: string;
  size?: number;
  color?: string;
  className?: string;
}

// In-memory cache for fast repeated rendering & printing
const qrCache = new Map<string, string>();

export const StudentQRCode: React.FC<StudentQRCodeProps> = ({
  value,
  size = 76,
  color = '#1e293b',
  className = '',
}) => {
  const cacheKey = `${value}_${size}_${color}`;
  const [dataUrl, setDataUrl] = useState<string>(() => qrCache.get(cacheKey) || '');

  useEffect(() => {
    if (qrCache.has(cacheKey)) {
      setDataUrl(qrCache.get(cacheKey)!);
      return;
    }

    let isMounted = true;
    QRCode.toDataURL(value || 'https://moeys.gov.kh', {
      width: Math.max(256, size * 3), // high density for crisp export/printing
      margin: 1,
      errorCorrectionLevel: 'M',
      color: {
        dark: color,
        light: '#ffffff',
      },
    })
      .then((url) => {
        qrCache.set(cacheKey, url);
        if (isMounted) {
          setDataUrl(url);
        }
      })
      .catch((err) => {
        console.error('Failed to generate student QR code:', err);
      });

    return () => {
      isMounted = false;
    };
  }, [value, size, color, cacheKey]);

  if (!dataUrl) {
    return (
      <div
        style={{ width: `${size}px`, height: `${size}px` }}
        className={`bg-slate-100 animate-pulse rounded flex items-center justify-center text-[9px] text-slate-400 font-mono ${className}`}
      >
        QR...
      </div>
    );
  }

  return (
    <img
      src={dataUrl}
      alt="Verification QR Code"
      style={{ width: `${size}px`, height: `${size}px` }}
      className={`block object-contain select-none pointer-events-none ${className}`}
    />
  );
};
