import React, { useState, useEffect } from 'react';
import { StudentData } from '../types/certificate';
import { toKhmerDigits, toLatinDigits } from '../utils/khmerNumbers';
import { X, Plus, Trash2, Upload, Download, Sparkles, Check } from 'lucide-react';

interface BatchTableModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: StudentData[];
  onSave: (updatedStudents: StudentData[]) => void;
}

export const BatchTableModal: React.FC<BatchTableModalProps> = ({
  isOpen,
  onClose,
  students,
  onSave,
}) => {
  const [data, setData] = useState<StudentData[]>(students);
  const [pasteText, setPasteText] = useState('');
  const [showPasteBox, setShowPasteBox] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setData(students);
    }
  }, [students, isOpen]);

  if (!isOpen) return null;

  const handleUpdateField = (index: number, field: keyof StudentData, value: string) => {
    const updated = [...data];
    updated[index] = {
      ...updated[index],
      [field]: value,
    };
    setData(updated);
  };

  const handleAddRow = () => {
    const last = data[data.length - 1] || {};
    const newRow: StudentData = {
      id: `std-${Date.now()}-${data.length}`,
      certNumber: toKhmerDigits(String(26 + data.length).padStart(3, '0')),
      name: '',
      gender: 'ស្រី',
      dob: last.dob || '១២-០៥-២០០៨',
      grade: last.grade || '២ខ',
      school: last.school || 'សាលាបឋមសិក្សា រោគ',
      rank: toKhmerDigits(data.length + 1),
      year: last.year || '២០២៥-២០២៦',
    };
    setData([...data, newRow]);
  };

  const handleDeleteRow = (index: number) => {
    if (data.length <= 1) return;
    setData(data.filter((_, i) => i !== index));
  };

  const handleAutoRankKhmer = () => {
    setData(
      data.map((item, idx) => ({
        ...item,
        rank: toKhmerDigits(idx + 1),
      }))
    );
  };

  const handleAutoRankLatin = () => {
    setData(
      data.map((item, idx) => ({
        ...item,
        rank: String(idx + 1),
      }))
    );
  };

  const handleAutoCertNumber = (start: number = 26) => {
    setData(
      data.map((item, idx) => ({
        ...item,
        certNumber: toKhmerDigits(String(start + idx).padStart(3, '0')),
      }))
    );
  };

  const handleParsePaste = () => {
    if (!pasteText.trim()) return;
    // Split by newlines, then tab or comma
    const lines = pasteText.trim().split('\n');
    const newStudents: StudentData[] = lines.map((line, idx) => {
      const parts = line.includes('\t') ? line.split('\t') : line.split(',');
      const cleanParts = parts.map((p) => p.trim().replace(/^["']|["']$/g, ''));
      const defaultSchool = data[0]?.school || 'សាលាបឋមសិក្សា';
      const defaultYear = data[0]?.year || '២០២៥-២០២៦';
      const defaultGrade = data[0]?.grade || '1A';

      let name = cleanParts[0] || `សិស្ស ${idx + 1}`;
      let gender = cleanParts[1] || 'ស្រី';
      let dob = '១២-០៥-២០០៨';
      let grade = defaultGrade;
      let rank = toKhmerDigits(idx + 1);
      let school = defaultSchool;
      let year = defaultYear;

      if (cleanParts.length >= 7) {
        dob = cleanParts[2] || '១២-០៥-២០០៨';
        grade = cleanParts[3] || defaultGrade;
        rank = cleanParts[4] || toKhmerDigits(idx + 1);
        school = cleanParts[5] || defaultSchool;
        year = cleanParts[6] || defaultYear;
      } else {
        grade = cleanParts[2] || defaultGrade;
        rank = cleanParts[3] || toKhmerDigits(idx + 1);
        school = cleanParts[4] || defaultSchool;
        year = cleanParts[5] || defaultYear;
      }

      return {
        id: `std-${Date.now()}-${idx}`,
        name,
        gender,
        dob,
        grade,
        rank,
        school,
        year,
      };
    });

    if (newStudents.length > 0) {
      setData(newStudents);
      setShowPasteBox(false);
      setPasteText('');
    }
  };

  const handleSaveAndClose = () => {
    onSave(data);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-xs p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-5xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between bg-slate-50">
          <div>
            <h2 className="text-base font-bold text-slate-900 font-moul">
              តារាងបញ្ចូលទិន្នន័យសិស្ស (Batch Editor)
            </h2>
            <p className="text-xs text-slate-500 mt-0.5">
              អាចកែសម្រួលផ្ទាល់ ឬបិទភ្ជាប់ (Paste) ចម្លងចេញពី Excel / Google Sheets
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar in Modal */}
        <div className="px-6 py-2.5 bg-amber-50/60 border-b border-amber-200/60 flex items-center justify-between flex-wrap gap-2 text-xs">
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleAddRow}
              className="flex items-center gap-1 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg font-semibold transition-colors shadow-2xs"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>បន្ថែមជួរ</span>
            </button>
            <button
              type="button"
              onClick={() => setShowPasteBox(!showPasteBox)}
              className="flex items-center gap-1 px-3 py-1.5 bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 rounded-lg font-medium transition-colors"
            >
              <Upload className="w-3.5 h-3.5 text-blue-600" />
              <span>បិទភ្ជាប់ពី Excel</span>
            </button>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-slate-500 font-medium">រៀបចំស្វ័យប្រវត្តិ៖</span>
            <button
              type="button"
              onClick={() => handleAutoCertNumber(26)}
              className="px-2 py-1 bg-blue-50 border border-blue-300 hover:bg-blue-100 text-blue-900 rounded font-semibold transition-colors"
              title="កំណត់លេខលិខិតចាប់ពីលេខ ០២៦ ប.ស.រ."
            >
              🔢 លេខលិខិត (០២៦...)
            </button>
            <button
              type="button"
              onClick={handleAutoRankKhmer}
              className="px-2 py-1 bg-white border border-slate-300 hover:bg-slate-50 rounded text-slate-700 font-medium"
            >
              ចំណាត់ថ្នាក់ខ្មែរ (១, ២, ៣...)
            </button>
            <button
              type="button"
              onClick={handleAutoRankLatin}
              className="px-2 py-1 bg-white border border-slate-300 hover:bg-slate-50 rounded text-slate-700 font-medium"
            >
              ចំណាត់ថ្នាក់សកល (1, 2, 3...)
            </button>
          </div>
        </div>

        {/* Paste from Excel box */}
        {showPasteBox && (
          <div className="p-4 bg-blue-50/70 border-b border-blue-200 space-y-2 text-xs">
            <label className="font-semibold text-blue-900 block">
              ចម្លងជួរឈរពី Excel (Format: ឈ្មោះ [tab] ភេទ [tab] ថ្ងៃខែឆ្នាំកំណើត [tab] ថ្នាក់ [tab] លេខ [tab] សាលា [tab] ឆ្នាំ)
            </label>
            <textarea
              rows={3}
              value={pasteText}
              onChange={(e) => setPasteText(e.target.value)}
              placeholder="សុខ ចិន្តា	ស្រី	១២-០៥-២០០៨	១២A	១	វិទ្យាល័យ ភ្នំស្រុក	២០២៥ - ២០២៦"
              className="w-full p-2 bg-white border border-blue-300 rounded-lg font-mono text-xs focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setShowPasteBox(false)}
                className="px-3 py-1 text-slate-600 hover:bg-slate-200 rounded"
              >
                បោះបង់
              </button>
              <button
                type="button"
                onClick={handleParsePaste}
                className="px-3 py-1 bg-blue-600 hover:bg-blue-700 text-white rounded font-medium"
              >
                នាំចូលទិន្នន័យ
              </button>
            </div>
          </div>
        )}

        {/* Table Content */}
        <div className="flex-1 overflow-auto p-6">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100 text-slate-700 font-semibold border-b border-slate-300">
                <th className="p-2.5 w-12 text-center">#</th>
                <th className="p-2.5 w-24 text-blue-900 font-bold text-center">លេខលិខិត</th>
                <th className="p-2.5">ឈ្មោះសិស្ស</th>
                <th className="p-2.5 w-24">ភេទ</th>
                <th className="p-2.5 w-32">ថ្ងៃខែឆ្នាំកំណើត</th>
                <th className="p-2.5 w-28">ថ្នាក់ទី</th>
                <th className="p-2.5 w-24">ចំណាត់ថ្នាក់</th>
                <th className="p-2.5">គ្រឹះស្ថានសិក្សា / សាលា</th>
                <th className="p-2.5 w-32">ឆ្នាំសិក្សា</th>
                <th className="p-2.5 w-12 text-center">លុប</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {data.map((student, idx) => (
                <tr key={student.id || idx} className="hover:bg-slate-50">
                  <td className="p-2.5 text-center font-mono text-slate-500 font-medium">
                    {idx + 1}
                  </td>
                  <td className="p-2">
                    <input
                      type="text"
                      value={student.certNumber || toKhmerDigits(String(26 + idx).padStart(3, '0'))}
                      onChange={(e) => handleUpdateField(idx, 'certNumber', e.target.value)}
                      placeholder={toKhmerDigits(String(26 + idx).padStart(3, '0'))}
                      className="w-full px-2 py-1 border border-blue-200 bg-blue-50/50 rounded focus:border-blue-500 focus:outline-none font-bold text-blue-700 text-center font-mono"
                      title="លេខលិខិតសរសើរ (ឧទាហរណ៍៖ ០២៦)"
                    />
                  </td>
                  <td className="p-2">
                    <input
                      type="text"
                      value={student.name}
                      onChange={(e) => handleUpdateField(idx, 'name', e.target.value)}
                      placeholder="ឈ្មោះសិស្ស"
                      className="w-full px-2 py-1 border border-slate-200 rounded focus:border-amber-500 focus:outline-none font-semibold text-slate-900"
                    />
                  </td>
                  <td className="p-2">
                    <select
                      value={student.gender}
                      onChange={(e) => handleUpdateField(idx, 'gender', e.target.value)}
                      className="w-full px-2 py-1 border border-slate-200 rounded focus:border-amber-500 focus:outline-none"
                    >
                      <option value="ប្រុស">ប្រុស</option>
                      <option value="ស្រី">ស្រី</option>
                    </select>
                  </td>
                  <td className="p-2">
                    <input
                      type="text"
                      value={student.dob || ''}
                      onChange={(e) => handleUpdateField(idx, 'dob', e.target.value)}
                      placeholder="១២-០៥-២០០៨"
                      className="w-full px-2 py-1 border border-slate-200 rounded focus:border-amber-500 focus:outline-none"
                    />
                  </td>
                  <td className="p-2">
                    <input
                      type="text"
                      value={student.grade}
                      onChange={(e) => handleUpdateField(idx, 'grade', e.target.value)}
                      placeholder="១២A"
                      className="w-full px-2 py-1 border border-slate-200 rounded focus:border-amber-500 focus:outline-none"
                    />
                  </td>
                  <td className="p-2">
                    <input
                      type="text"
                      value={student.rank}
                      onChange={(e) => handleUpdateField(idx, 'rank', e.target.value)}
                      placeholder="១"
                      className="w-full px-2 py-1 border border-slate-200 rounded focus:border-amber-500 focus:outline-none font-bold text-red-600"
                    />
                  </td>
                  <td className="p-2">
                    <input
                      type="text"
                      value={student.school}
                      onChange={(e) => handleUpdateField(idx, 'school', e.target.value)}
                      placeholder="ឈ្មោះសាលា"
                      className="w-full px-2 py-1 border border-slate-200 rounded focus:border-amber-500 focus:outline-none"
                    />
                  </td>
                  <td className="p-2">
                    <input
                      type="text"
                      value={student.year}
                      onChange={(e) => handleUpdateField(idx, 'year', e.target.value)}
                      placeholder="២០២៥ - ២០២៦"
                      className="w-full px-2 py-1 border border-slate-200 rounded focus:border-amber-500 focus:outline-none"
                    />
                  </td>
                  <td className="p-2 text-center">
                    <button
                      type="button"
                      disabled={data.length <= 1}
                      onClick={() => handleDeleteRow(idx)}
                      className="p-1 text-slate-400 hover:text-red-600 rounded disabled:opacity-30 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
          <span className="text-xs text-slate-500 font-medium">
            សរុប៖ {data.length} នាក់
          </span>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-200 rounded-lg transition-colors"
            >
              បោះបង់
            </button>
            <button
              type="button"
              onClick={handleSaveAndClose}
              className="flex items-center gap-1.5 px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors"
            >
              <Check className="w-4 h-4" />
              <span>រក្សាទុកទិន្នន័យ</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
