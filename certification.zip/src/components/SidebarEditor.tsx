import React, { useState } from 'react';
import {
  CertificateConfig,
  CertificateStyles,
  CertificateTemplate,
  StudentData,
} from '../types/certificate';
import { FONT_OPTIONS, PRESET_TEMPLATES, BACKGROUND_PRESETS, SAMPLE_STUDENTS } from '../constants/defaultConfig';
import { toKhmerDigits, toLatinDigits, formatKhmerDate } from '../utils/khmerNumbers';
import {
  generateTodaySolarDate,
  generateTodayLunarDate,
  LUNAR_DATE_PRESETS,
  SOLAR_DATE_PRESETS,
} from '../utils/khmerDateHelper';
import {
  DEFAULT_QR_URL_TEMPLATE,
  DEFAULT_QR_TEXT_TEMPLATE,
  DEFAULT_QR_JSON_TEMPLATE,
  generateStudentQrPayload,
} from '../utils/qrCodeHelper';
import {
  FileText,
  Sliders,
  Image,
  Users,
  BookmarkCheck,
  Plus,
  Trash2,
  Upload,
  RotateCcw,
  Sparkles,
  Award,
  Stamp,
  Copy,
  Check,
  Calendar,
  Layers,
  Moon,
  Sun,
  AlignLeft,
  AlignCenter,
  AlignRight,
  AlignJustify,
  QrCode,
  Hash,
} from 'lucide-react';

interface SidebarEditorProps {
  config: CertificateConfig;
  onChangeConfig: (newConfig: CertificateConfig) => void;
  students: StudentData[];
  onChangeStudents: (students: StudentData[]) => void;
  activeStudentIndex: number;
  onSelectStudent: (index: number) => void;
  onResetToDefault: () => void;
}

type TabKey = 'content' | 'styles' | 'graphics' | 'students' | 'presets';

export const SidebarEditor: React.FC<SidebarEditorProps> = ({
  config,
  onChangeConfig,
  students,
  onChangeStudents,
  activeStudentIndex,
  onSelectStudent,
  onResetToDefault,
}) => {
  const [activeTab, setActiveTab] = useState<TabKey>('content');
  const [copiedJson, setCopiedJson] = useState(false);
  const [jsonInput, setJsonInput] = useState('');
  const [jsonError, setJsonError] = useState<string | null>(null);
  const [actionFeedback, setActionFeedback] = useState<string | null>(null);

  const currentStudent = students[activeStudentIndex] || students[0];

  // Helper to update template fields
  const updateTemplate = (updates: Partial<CertificateTemplate>) => {
    onChangeConfig({
      ...config,
      template: {
        ...config.template,
        ...updates,
      },
    });
  };

  // Helper to update nested styles
  const updateStyle = <K extends keyof CertificateStyles>(
    key: K,
    updates: Partial<CertificateStyles[K]>
  ) => {
    onChangeConfig({
      ...config,
      styles: {
        ...config.styles,
        [key]: {
          ...config.styles[key],
          ...updates,
        },
      },
    });
  };

  const updateLayout = (updates: Partial<NonNullable<CertificateStyles['layout']>>) => {
    const prev = config.styles.layout || {
      paddingTop: 125,
      paddingSides: 105,
      paddingBottom: 80,
    };
    onChangeConfig({
      ...config,
      styles: {
        ...config.styles,
        layout: {
          ...prev,
          ...updates,
        },
      },
    });
  };

  // Helper to update student data
  const updateCurrentStudent = (updates: Partial<StudentData>) => {
    const updated = [...students];
    updated[activeStudentIndex] = {
      ...updated[activeStudentIndex],
      ...updates,
    };
    onChangeStudents(updated);
  };

  // File upload helper
  const handleImageUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    callback: (base64Url: string) => void
  ) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        if (event.target?.result) {
          callback(event.target.result as string);
        }
      };
      reader.readAsDataURL(file);
    }
  };

  // Apply Khmer Lunar & Solar Date helper
  const handleSetTodayKhmerDate = () => {
    const todaySolar = generateTodaySolarDate('ភ្នំស្រុក');
    const todayLunar = generateTodayLunarDate();
    updateTemplate({
      lunarDate: todayLunar,
      solarDate: todaySolar,
      datePlace: `${todayLunar}\n${todaySolar}`,
      showLunarDate: true,
      showSolarDate: true,
    });
  };

  const handleSetBlankDates = () => {
    const blankLunar = 'ថ្ងៃ.....................ខែ.................. ឆ្នាំមមី អដ្ឋស័ក ព.ស.២៥៧០';
    const blankSolar = '.................. ថ្ងៃទី.......... ខែ............. ឆ្នាំ២០២៦';
    updateTemplate({
      lunarDate: blankLunar,
      solarDate: blankSolar,
      datePlace: `${blankLunar}\n${blankSolar}`,
      showLunarDate: true,
      showSolarDate: true,
    });
  };

  // Copy Config as JSON
  const handleCopyConfigJson = () => {
    const jsonStr = JSON.stringify(
      {
        template: config.template,
        styles: config.styles,
        bgUrl: config.bgUrl.startsWith('data:') ? '[Base64 Image]' : config.bgUrl,
        bgHue: config.bgHue,
      },
      null,
      2
    );
    navigator.clipboard.writeText(jsonStr);
    setCopiedJson(true);
    setTimeout(() => setCopiedJson(false), 2000);
  };

  // Import JSON
  const handleApplyJson = () => {
    try {
      setJsonError(null);
      const parsed = JSON.parse(jsonInput);
      if (!parsed.template || !parsed.styles) {
        throw new Error('ទម្រង់ JSON ត្រូវតែមាន template និង styles');
      }
      onChangeConfig({
        ...config,
        template: {
          ...config.template,
          ...parsed.template,
        },
        styles: {
          ...config.styles,
          ...parsed.styles,
        },
        bgUrl: parsed.bgUrl && !parsed.bgUrl.includes('[Base64') ? parsed.bgUrl : config.bgUrl,
        bgHue: typeof parsed.bgHue === 'number' ? parsed.bgHue : config.bgHue,
      });
      alert('បានអនុវត្តការកំណត់ JSON ដោយជោគជ័យ!');
    } catch (err: any) {
      setJsonError(err.message || 'កំហុសទម្រង់ JSON');
    }
  };

  // Apply Preset
  const handleApplyPreset = (preset: (typeof PRESET_TEMPLATES)[0]) => {
    updateTemplate({
      title: preset.title,
      subtitle: preset.subtitle,
      studentIntro: preset.studentIntro,
      description: preset.descriptionText,
      wishes: preset.wishes,
    });
  };

  return (
    <div className="flex flex-col h-full bg-white border-r border-slate-200 w-full md:w-[480px] lg:w-[520px] shadow-sm flex-shrink-0">
      {/* Top Header */}
      <div className="p-4 border-b border-slate-200 bg-gradient-to-r from-amber-50 to-orange-50/50">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center shadow-sm">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h2 className="font-moul text-base text-amber-950">កម្មវិធីបង្កើតប័ណ្ណសរសើរ</h2>
              <p className="text-xs text-slate-500 font-medium">Cambodian Certificate Generator</p>
            </div>
          </div>
          <button
            onClick={onResetToDefault}
            title="កំណត់ឡើងវិញជាលំនាំដើម"
            className="p-2 rounded-lg text-slate-500 hover:text-red-600 hover:bg-red-50 text-xs flex items-center gap-1 transition-colors"
          >
            <RotateCcw className="w-4 h-4" />
            <span className="hidden sm:inline">លំនាំដើម</span>
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center space-x-1 mt-4 p-1 bg-slate-100 rounded-xl overflow-x-auto text-xs font-medium">
          <button
            onClick={() => setActiveTab('content')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'content'
                ? 'bg-white text-amber-900 shadow-sm font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>ខ្លឹមសារ</span>
          </button>
          <button
            onClick={() => setActiveTab('styles')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'styles'
                ? 'bg-white text-amber-900 shadow-sm font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>រចនាបថ</span>
          </button>
          <button
            onClick={() => setActiveTab('graphics')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'graphics'
                ? 'bg-white text-amber-900 shadow-sm font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-4 h-4" />
            <span>ផ្ទៃ & ត្រា</span>
          </button>
          <button
            onClick={() => setActiveTab('students')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'students'
                ? 'bg-white text-amber-900 shadow-sm font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>បញ្ជីសិស្ស ({students.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('presets')}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg transition-all whitespace-nowrap ${
              activeTab === 'presets'
                ? 'bg-white text-amber-900 shadow-sm font-semibold'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <BookmarkCheck className="w-4 h-4" />
            <span>គំរូ & JSON</span>
          </button>
        </div>
      </div>

      {/* Tab Body */}
      <div className="flex-1 overflow-y-auto p-4 space-y-5 text-sm">
        {/* ===================== TAB 1: CONTENT ===================== */}
        {activeTab === 'content' && (
          <div className="space-y-4">
            {/* Active Student Quick Selector */}
            <div className="p-3 bg-amber-50/70 border border-amber-200/70 rounded-xl space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-amber-900 flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-amber-600" />
                  សិស្សកំពុងកែសម្រួល៖
                </span>
                <span className="text-xs font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full">
                  #{activeStudentIndex + 1} នៃ {students.length}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-xs text-slate-500 font-medium">ឈ្មោះសិស្ស</label>
                  <input
                    type="text"
                    value={currentStudent.name}
                    onChange={(e) => updateCurrentStudent({ name: e.target.value })}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-sm font-semibold text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    placeholder="ឈ្មោះសិស្ស"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 font-medium">ភេទ</label>
                  <select
                    value={currentStudent.gender}
                    onChange={(e) => updateCurrentStudent({ gender: e.target.value })}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  >
                    <option value="ប្រុស">ប្រុស</option>
                    <option value="ស្រី">ស្រី</option>
                  </select>
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <label className="text-xs text-slate-500 font-medium">ថ្ងៃខែឆ្នាំកំណើត (DOB)</label>
                    <div className="flex gap-1">
                      <button
                        type="button"
                        onClick={() =>
                          updateCurrentStudent({
                            dob: toKhmerDigits(currentStudent.dob || '12-05-2008'),
                          })
                        }
                        title="បំប្លែងជាលេខខ្មែរ"
                        className="text-[10px] text-amber-700 hover:bg-amber-100 px-1 rounded font-mono"
                      >
                        ខ្មែរ
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          updateCurrentStudent({
                            dob: toLatinDigits(currentStudent.dob || '១២-០៥-២០០៨'),
                          })
                        }
                        title="បំប្លែងជាលេខសកល"
                        className="text-[10px] text-slate-600 hover:bg-slate-200 px-1 rounded font-mono"
                      >
                        123
                      </button>
                    </div>
                  </div>
                  <input
                    type="text"
                    value={currentStudent.dob || ''}
                    onChange={(e) => updateCurrentStudent({ dob: e.target.value })}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    placeholder="១២-០៥-២០០៨"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 font-medium">ថ្នាក់ទី</label>
                  <input
                    type="text"
                    value={currentStudent.grade}
                    onChange={(e) => updateCurrentStudent({ grade: e.target.value })}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    placeholder="ឧ. ១២A"
                  />
                </div>
                <div>
                  <div className="flex items-center justify-between">
                    <label className="text-xs text-slate-500 font-medium">ចំណាត់ថ្នាក់លេខ</label>
                    <div className="flex gap-1">
                      <button
                        type="button"
                        onClick={() => updateCurrentStudent({ rank: toKhmerDigits(currentStudent.rank) })}
                        title="បំប្លែងជាលេខខ្មែរ"
                        className="text-[10px] text-amber-700 hover:bg-amber-100 px-1 rounded"
                      >
                        ខ្មែរ
                      </button>
                      <button
                        type="button"
                        onClick={() => updateCurrentStudent({ rank: toLatinDigits(currentStudent.rank) })}
                        title="បំប្លែងជាលេខសកល"
                        className="text-[10px] text-slate-600 hover:bg-slate-200 px-1 rounded"
                      >
                        123
                      </button>
                    </div>
                  </div>
                  <input
                    type="text"
                    value={currentStudent.rank}
                    onChange={(e) => updateCurrentStudent({ rank: e.target.value })}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-sm font-bold text-red-600 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    placeholder="ឧ. ១"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-500 font-medium">ឆ្នាំសិក្សា</label>
                  <input
                    type="text"
                    value={currentStudent.year}
                    onChange={(e) => updateCurrentStudent({ year: e.target.value })}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    placeholder="២០២៥ - ២០២៦"
                  />
                </div>
              </div>
              <div className="pt-1">
                <label className="text-xs text-slate-500 font-medium">គ្រឹះស្ថានសិក្សា/សាលា</label>
                <input
                  type="text"
                  value={currentStudent.school}
                  onChange={(e) => updateCurrentStudent({ school: e.target.value })}
                  className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-sm text-slate-900 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  placeholder="វិទ្យាល័យ..."
                />
              </div>
            </div>

            {/* Certificate Headers */}
            <div className="space-y-3 pt-2">
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                <FileText className="w-3.5 h-3.5 text-amber-600" />
                ផ្នែកក្បាលទំព័រ & បាវចនាជាតិ
              </h3>

              {/* Institution Header Block */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-700 block">
                    ចំណងជើងស្ថាប័ន (ខាងឆ្វេង)
                  </label>
                  {/* Alignment buttons */}
                  <div className="flex items-center bg-white border border-slate-300 rounded-lg p-0.5">
                    <button
                      type="button"
                      onClick={() =>
                        onChangeConfig({
                          ...config,
                          styles: {
                            ...config.styles,
                            header: { ...config.styles.header, align: 'left' },
                          },
                        })
                      }
                      className={`p-1 rounded text-xs transition-colors ${
                        (config.styles.header?.align || 'left') === 'left'
                          ? 'bg-amber-100 text-amber-900 font-bold'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                      title="តម្រឹមឆ្វេង (ស្តង់ដារ)"
                    >
                      <AlignLeft className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        onChangeConfig({
                          ...config,
                          styles: {
                            ...config.styles,
                            header: { ...config.styles.header, align: 'center' },
                          },
                        })
                      }
                      className={`p-1 rounded text-xs transition-colors ${
                        config.styles.header?.align === 'center'
                          ? 'bg-amber-100 text-amber-900 font-bold'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                      title="តម្រឹមកណ្តាល"
                    >
                      <AlignCenter className="w-3.5 h-3.5" />
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        onChangeConfig({
                          ...config,
                          styles: {
                            ...config.styles,
                            header: { ...config.styles.header, align: 'right' },
                          },
                        })
                      }
                      className={`p-1 rounded text-xs transition-colors ${
                        config.styles.header?.align === 'right'
                          ? 'bg-amber-100 text-amber-900 font-bold'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                      title="តម្រឹមស្តាំ"
                    >
                      <AlignRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Quick Header Presets */}
                <div className="flex flex-wrap gap-1 text-[10px]">
                  <button
                    type="button"
                    onClick={() =>
                      updateTemplate({
                        header:
                          'មន្ទីរអប់រំ យុវជន និងកីឡាខេត្តបន្ទាយមានជ័យ\nការិយាល័យអប់រំ យុវជន និងកីឡាស្រុកភ្នំស្រុក\nសាលាបឋមសិក្សា រោគ\nលេខ : {certNo} ប.ស.រ.',
                        logoTop: null,
                        showLogoTop: false,
                        subtitle: 'នាយិកាសាលាបឋមសិក្សា រោគ',
                      })
                    }
                    className="px-2 py-0.5 bg-amber-50 hover:bg-amber-100 border border-amber-300 rounded font-medium text-amber-900 transition-colors"
                  >
                    🏛️ សាលាបឋមសិក្សា រោគ (៤ជួរ: ០២៦ ប.ស.រ.)
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      updateTemplate({
                        header:
                          'មន្ទីរអប់រំ យុវជន និងកីឡាខេត្តបន្ទាយមានជ័យ\nការិយាល័យអប់រំ យុវជន និងកីឡាស្រុកភ្នំស្រុក\n{school}\nលេខ : {certNo} ប.ស.រ.',
                        logoTop: null,
                        showLogoTop: false,
                      })
                    }
                    className="px-2 py-0.5 bg-white hover:bg-slate-100 border border-slate-300 rounded text-slate-700 transition-colors"
                  >
                    🏛️ ស្រុកភ្នំស្រុក ({'{school}'})
                  </button>
                </div>

                <textarea
                  rows={4}
                  value={config.template.header}
                  onChange={(e) => updateTemplate({ header: e.target.value })}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-lg text-xs leading-relaxed focus:ring-2 focus:ring-amber-500 focus:outline-none font-medium"
                />

                {/* Helper tags for header */}
                <div className="flex items-center gap-1.5 flex-wrap text-[10px]">
                  <span className="text-slate-400">ចុចបន្ថែម៖</span>
                  <button
                    type="button"
                    onClick={() => {
                      const cur = config.template.header || '';
                      if (!cur.includes('{certNo}')) {
                        updateTemplate({ header: cur.includes('លេខ') ? cur.replace(/លេខ\s*[:៖]?\s*[…\.]+/g, 'លេខ : {certNo}') : `${cur.trim()}\nលេខ : {certNo} ប.ស.រ.` });
                      }
                    }}
                    className="px-1.5 py-0.5 bg-blue-50 hover:bg-blue-100 text-blue-700 font-mono font-semibold rounded border border-blue-200 transition-colors"
                  >
                    + {'{certNo}'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const cur = config.template.header || '';
                      if (!cur.includes('ប.ស.រ.')) {
                        updateTemplate({ header: `${cur.trim()} ប.ស.រ.` });
                      }
                    }}
                    className="px-1.5 py-0.5 bg-blue-50 hover:bg-blue-100 text-blue-700 font-medium rounded border border-blue-200 transition-colors"
                  >
                    + ប.ស.រ.
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const cur = config.template.header || '';
                      if (!cur.includes('ការិយាល័យអប់រំ យុវជន និងកីឡាស្រុកភ្នំស្រុក')) {
                        updateTemplate({ header: cur.replace('មន្ទីរអប់រំ យុវជន និងកីឡាខេត្តបន្ទាយមានជ័យ', 'មន្ទីរអប់រំ យុវជន និងកីឡាខេត្តបន្ទាយមានជ័យ\nការិយាល័យអប់រំ យុវជន និងកីឡាស្រុកភ្នំស្រុក') });
                      }
                    }}
                    className="px-1.5 py-0.5 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded border border-amber-200 transition-colors"
                  >
                    + ការិយាល័យអប់រំ ស្រុកភ្នំស្រុក
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const cur = config.template.header || '';
                      updateTemplate({ header: `${cur.trim()}\n{school}` });
                    }}
                    className="px-1.5 py-0.5 bg-slate-50 hover:bg-slate-100 text-slate-700 font-mono rounded border border-slate-200 transition-colors"
                  >
                    + {'{school}'}
                  </button>
                </div>

                {/* Show/Hide Logo */}
                <label className="flex items-center gap-1.5 text-[11px] text-slate-600 cursor-pointer pt-0.5">
                  <input
                    type="checkbox"
                    checked={config.template.showLogoTop ?? false}
                    onChange={(e) => updateTemplate({ showLogoTop: e.target.checked })}
                    className="rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                  />
                  <span>ដាក់ Logo ស្ថាប័នពីលើ</span>
                </label>
              </div>

              {/* Document Reference Number (លេខលិខិត) Section */}
              <div className="p-3 bg-blue-50/70 border border-blue-200 rounded-xl space-y-3 shadow-2xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5">
                    <Hash className="w-4 h-4 text-blue-700" />
                    <span className="text-xs font-bold text-blue-950">
                      លេខលិខិត / លេខប័ណ្ណ (Document No.)
                    </span>
                  </div>
                  <label className="flex items-center gap-1.5 text-[11px] text-blue-900 font-semibold cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.template.showCertNumber ?? true}
                      onChange={(e) => updateTemplate({ showCertNumber: e.target.checked })}
                      className="rounded border-blue-300 text-blue-600 focus:ring-blue-500"
                    />
                    <span>បង្ហាញលើប័ណ្ណ</span>
                  </label>
                </div>

                {/* Live Preview badge of Document Number */}
                <div className="flex items-center justify-between bg-white px-3 py-2 rounded-lg border border-blue-200 text-xs">
                  <span className="text-slate-600 font-medium">ទម្រង់បច្ចុប្បន្ន (សិស្សនេះ)៖</span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-slate-800 font-medium">លេខ :</span>
                    <span
                      className="font-bold tracking-wider px-2 py-0.5 rounded bg-blue-50/80 border border-blue-200 font-mono text-sm"
                      style={{ color: config.styles.certNumber?.color || '#1d4ed8' }}
                    >
                      {currentStudent.certNumber || '០២៦'} ប.ស.រ.
                    </span>
                  </div>
                </div>

                {/* Quick Ink Color Presets (ពណ៌ទឹកប៊ិច) */}
                <div>
                  <div className="flex items-center justify-between text-[11px] text-slate-600 mb-1.5">
                    <span className="font-semibold text-slate-800">
                      ពណ៌ទឹកប៊ិច (Pen Blue Ink Color)
                    </span>
                    <span
                      className="font-bold text-[11px] px-1.5 py-0.5 rounded"
                      style={{ color: config.styles.certNumber?.color || '#1d4ed8' }}
                    >
                      ● {config.styles.certNumber?.color === '#1d4ed8' ? 'ពណ៌ទឹកប៊ិចខៀវ' : config.styles.certNumber?.color || '#1d4ed8'}
                    </span>
                  </div>
                  <div className="flex items-center gap-1.5 flex-wrap">
                    {[
                      { name: 'ទឹកប៊ិចខៀវ (ស្តង់ដារ)', color: '#1d4ed8' },
                      { name: 'ទឹកប៊ិចក្រមៅ', color: '#0f3ba2' },
                      { name: 'ទឹកប៊ិចខៀវស្រស់', color: '#2563eb' },
                      { name: 'ខ្មៅធម្មតា', color: '#0f172a' },
                      { name: 'ក្រហម', color: '#b91c1c' },
                    ].map((c) => (
                      <button
                        key={c.color}
                        type="button"
                        onClick={() =>
                          onChangeConfig({
                            ...config,
                            styles: {
                              ...config.styles,
                              certNumber: {
                                ...config.styles.certNumber,
                                color: c.color,
                                bold: true,
                              },
                            },
                          })
                        }
                        className={`flex items-center gap-1 px-2 py-1 rounded text-[11px] border transition-all ${
                          (config.styles.certNumber?.color || '#1d4ed8') === c.color
                            ? 'border-blue-600 ring-2 ring-blue-300 font-bold shadow-xs'
                            : 'border-slate-200 hover:border-slate-300 bg-white'
                        }`}
                        style={{ color: c.color }}
                      >
                        <span
                          className="w-2.5 h-2.5 rounded-full inline-block"
                          style={{ backgroundColor: c.color }}
                        />
                        <span>{c.name}</span>
                      </button>
                    ))}
                    <div className="flex items-center gap-1 ml-auto">
                      <input
                        type="color"
                        value={config.styles.certNumber?.color || '#1d4ed8'}
                        onChange={(e) =>
                          onChangeConfig({
                            ...config,
                            styles: {
                              ...config.styles,
                              certNumber: {
                                ...config.styles.certNumber,
                                color: e.target.value,
                                bold: true,
                              },
                            },
                          })
                        }
                        className="w-6 h-6 rounded cursor-pointer border border-slate-300"
                        title="ជ្រើសរើសពណ៌ផ្ទាល់ខ្លួន"
                      />
                    </div>
                  </div>
                </div>

                {/* Auto-numbering action for all 49 students */}
                <div className="pt-2 border-t border-blue-200 flex items-center justify-between gap-2 flex-wrap">
                  <div className="text-[11px] text-slate-700">
                    <span>រៀបចំលេខ </span>
                    <span className="font-bold text-blue-800 font-mono">០២៦</span>
                    <span> ដល់ </span>
                    <span className="font-bold text-blue-800 font-mono">
                      {toKhmerDigits(String(25 + students.length).padStart(3, '0'))}
                    </span>
                    <span> ប.ស.រ. ({students.length} នាក់)</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const updated = students.map((s, idx) => ({
                        ...s,
                        certNumber: toKhmerDigits(String(26 + idx).padStart(3, '0')),
                      }));
                      onChangeStudents(updated);
                      // Make sure header has {certNo} ប.ស.រ.
                      let hdr = config.template.header || '';
                      hdr = hdr.replace(/ប[០-៩0-9\s]*ស[០-៩0-9\s]*រ[០-៩0-9\s]*/g, 'ប.ស.រ.');
                      if (hdr.includes('លេខ')) {
                        hdr = hdr.replace(/លេខ\s*[:៖]?\s*.*$/m, 'លេខ : {certNo} ប.ស.រ.');
                      } else {
                        hdr = `${hdr.trim()}\nលេខ : {certNo} ប.ស.រ.`;
                      }
                      updateTemplate({ header: hdr });
                      setActionFeedback('បានរៀបចំលេខលិខិត ចាប់ពី ០២៦ ប.ស.រ. (ពណ៌ទឹកប៊ិច) ដោយជោគជ័យ!');
                      setTimeout(() => setActionFeedback(null), 3000);
                    }}
                    className="px-2.5 py-1.5 bg-blue-600 hover:bg-blue-700 text-white rounded-lg text-xs font-semibold shadow-2xs transition-colors flex items-center gap-1"
                  >
                    <Sparkles className="w-3.5 h-3.5" />
                    <span>រៀបចំលេខស្វ័យប្រវត្តិ</span>
                  </button>
                </div>

                {actionFeedback && (
                  <div className="p-2 bg-emerald-50 border border-emerald-200 rounded-lg text-emerald-800 text-[11px] font-medium flex items-center gap-1.5 animate-in fade-in">
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{actionFeedback}</span>
                  </div>
                )}
              </div>

              <div>
                <label className="text-xs text-slate-600 font-medium block mb-1">
                  បាវចនាជាតិ (ខាងស្តាំ)
                </label>
                <textarea
                  rows={2}
                  value={config.template.motto}
                  onChange={(e) => updateTemplate({ motto: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs leading-relaxed focus:ring-2 focus:ring-amber-500 focus:outline-none font-medium"
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 font-medium block mb-1">
                  សញ្ញាលម្អបាវចនា
                </label>
                <input
                  type="text"
                  value={config.template.mottoDecor}
                  onChange={(e) => updateTemplate({ mottoDecor: e.target.value })}
                  className="w-full px-3 py-1.5 border border-slate-300 rounded-lg text-xs focus:ring-2 focus:ring-amber-500 focus:outline-none"
                  placeholder="❁❁❁&❁❁❁"
                />
              </div>
            </div>

            {/* Certificate Title & Subtitle */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  ចំណងជើងប័ណ្ណសរសើរ
                </h3>
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.template.showTitle ?? true}
                      onChange={(e) => updateTemplate({ showTitle: e.target.checked })}
                      className="rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                    />
                    <span>បង្ហាញចំណងជើងធំ</span>
                  </label>
                  <label className="flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.template.showSubtitle ?? true}
                      onChange={(e) => updateTemplate({ showSubtitle: e.target.checked })}
                      className="rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                    />
                    <span>បង្ហាញចំណងជើងរង</span>
                  </label>
                </div>
              </div>
              {(config.template.showTitle ?? true) && (
                <div>
                  <label className="text-xs text-slate-600 font-medium block mb-1">
                    ចំណងជើងធំ
                  </label>
                  <input
                    type="text"
                    value={config.template.title}
                    onChange={(e) => updateTemplate({ title: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm font-moul text-red-600 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    placeholder="បណ្ណសរសើរ"
                  />
                </div>
              )}

              {(config.template.showSubtitle ?? true) && (
                <div>
                  <label className="text-xs text-slate-600 font-medium block mb-1">
                    ចំណងជើងរង (ប្រើ {'{school}'} ដើម្បីជំនួសឈ្មោះសាលា)
                  </label>
                  <input
                    type="text"
                    value={config.template.subtitle}
                    onChange={(e) => updateTemplate({ subtitle: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm text-blue-700 focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    placeholder="នាយក{school}"
                  />
                </div>
              )}
            </div>

            {/* Certificate Main Body */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  ខ្លឹមសារកោតសរសើរ
                </h3>
                {/* Alignment & Indent controls */}
                <div className="flex items-center gap-2">
                  <div className="flex items-center bg-slate-100 border border-slate-300 rounded-lg p-0.5">
                    <button
                      type="button"
                      onClick={() =>
                        onChangeConfig({
                          ...config,
                          styles: {
                            ...config.styles,
                            body: { ...config.styles.body, align: 'left' },
                          },
                        })
                      }
                      className={`px-2 py-1 rounded text-xs transition-colors ${
                        (config.styles.body?.align || 'left') !== 'center'
                          ? 'bg-white text-amber-900 font-bold shadow-2xs'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                      title="តម្រឹមឆ្វេង (ស្តង់ដារផ្លូវការ)"
                    >
                      <AlignLeft className="w-3.5 h-3.5 inline mr-1" />
                      ឆ្វេង
                    </button>
                    <button
                      type="button"
                      onClick={() =>
                        onChangeConfig({
                          ...config,
                          styles: {
                            ...config.styles,
                            body: { ...config.styles.body, align: 'center' },
                          },
                        })
                      }
                      className={`px-2 py-1 rounded text-xs transition-colors ${
                        config.styles.body?.align === 'center'
                          ? 'bg-white text-amber-900 font-bold shadow-2xs'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                      title="តម្រឹមកណ្តាល"
                    >
                      <AlignCenter className="w-3.5 h-3.5 inline mr-1" />
                      កណ្តាល
                    </button>
                  </div>
                </div>
              </div>

              {/* Indent Control */}
              <div className="flex items-center justify-between p-2 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                <span className="font-semibold text-slate-700">ចូលបន្ទាត់ដំបូង (Indent)៖</span>
                <div className="flex items-center gap-1">
                  {[0, 32, 48, 64].map((px) => (
                    <button
                      key={px}
                      type="button"
                      onClick={() =>
                        onChangeConfig({
                          ...config,
                          styles: {
                            ...config.styles,
                            body: { ...config.styles.body, indent: px },
                          },
                        })
                      }
                      className={`px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                        (config.styles.body?.indent ?? 48) === px
                          ? 'bg-amber-600 text-white font-bold'
                          : 'bg-white border border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      {px === 0 ? 'គ្មាន' : `${px}px`}
                    </button>
                  ))}
                </div>
              </div>

              {/* Tag Quick Chips */}
              <div className="flex flex-wrap gap-1.5 p-2 bg-slate-50 border border-slate-200 rounded-lg text-[11px]">
                {[
                  { tag: '{name}', label: 'ឈ្មោះ {name}' },
                  { tag: '{gender}', label: 'ភេទ {gender}' },
                  { tag: '{dob}', label: 'ថ្ងៃខែកំណើត {dob}' },
                  { tag: '{grade}', label: 'ថ្នាក់ {grade}' },
                  { tag: '{school}', label: 'សាលា {school}' },
                  { tag: '{rank}', label: 'ចំណាត់ថ្នាក់ {rank}' },
                  { tag: '{year}', label: 'ឆ្នាំសិក្សា {year}' },
                ].map((item) => (
                  <button
                    key={item.tag}
                    type="button"
                    onClick={() =>
                      updateTemplate({
                        studentIntro: config.template.studentIntro + ' ' + item.tag,
                      })
                    }
                    className="px-2 py-0.5 bg-white hover:bg-amber-100 hover:text-amber-900 border border-slate-200 hover:border-amber-300 rounded font-medium text-slate-700 transition-colors shadow-2xs"
                    title={`ចុចដើម្បីបញ្ចូល ${item.tag} ទៅកាន់ឃ្លាកោតសរសើរ`}
                  >
                    + {item.label}
                  </button>
                ))}
              </div>

              <div>
                <label className="text-xs text-slate-600 font-medium block mb-1">
                  ឃ្លាកោតសរសើរ (Intro)
                </label>
                <textarea
                  rows={2}
                  value={config.template.studentIntro}
                  onChange={(e) => updateTemplate({ studentIntro: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs leading-relaxed focus:ring-2 focus:ring-amber-500 focus:outline-none font-medium"
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 font-medium block mb-1">
                  លទ្ធផល និងចំណាត់ថ្នាក់ (Description)
                </label>
                <textarea
                  rows={2}
                  value={config.template.description}
                  onChange={(e) => updateTemplate({ description: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs leading-relaxed focus:ring-2 focus:ring-amber-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="text-xs text-slate-600 font-medium block mb-1">
                  ពាក្យជូនពរ (Wishes)
                </label>
                <textarea
                  rows={3}
                  value={config.template.wishes}
                  onChange={(e) => updateTemplate({ wishes: e.target.value })}
                  className="w-full px-3 py-2 border border-slate-300 rounded-lg text-xs leading-relaxed focus:ring-2 focus:ring-amber-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Date & Signature */}
            <div className="space-y-3 pt-2 border-t border-slate-200">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Calendar className="w-3.5 h-3.5 text-amber-600" />
                  កាលបរិច្ឆេទ & ហត្ថលេខា
                </h3>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleSetBlankDates}
                    className="text-[11px] text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200 px-2 py-0.5 rounded transition-colors"
                    title="កំណត់គំរូទទេសម្រាប់សរសេរដៃ"
                  >
                    គំរូទទេ
                  </button>
                  <button
                    type="button"
                    onClick={handleSetTodayKhmerDate}
                    className="text-[11px] text-amber-800 hover:text-amber-900 bg-amber-100 hover:bg-amber-200 px-2 py-0.5 rounded font-medium flex items-center gap-1 transition-colors"
                  >
                    <Sparkles className="w-3 h-3 text-amber-600" />
                    ថ្ងៃនេះ (ស្វ័យប្រវត្តិ)
                  </button>
                </div>
              </div>

              {/* Date Alignment Controls */}
              <div className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs">
                <span className="font-semibold text-slate-700">តម្រឹមកាលបរិច្ឆេទ (ចន្ទគតិ & សុរិយគតិ)៖</span>
                <div className="flex items-center bg-white border border-slate-300 rounded-lg p-0.5 shadow-2xs">
                  <button
                    type="button"
                    onClick={() => updateStyle('date', { align: 'left' })}
                    className={`px-2.5 py-1 rounded text-xs transition-colors flex items-center gap-1 ${
                      (config.styles.date?.align || 'left') === 'left'
                        ? 'bg-amber-100 text-amber-900 font-bold'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                    title="តម្រឹមឆ្វេង (ស្តង់ដារផ្លូវការ)"
                  >
                    <AlignLeft className="w-3.5 h-3.5" />
                    <span>ឆ្វេង</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => updateStyle('date', { align: 'center' })}
                    className={`px-2.5 py-1 rounded text-xs transition-colors flex items-center gap-1 ${
                      config.styles.date?.align === 'center'
                        ? 'bg-amber-100 text-amber-900 font-bold'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                    title="តម្រឹមកណ្តាល"
                  >
                    <AlignCenter className="w-3.5 h-3.5" />
                    <span>កណ្តាល</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => updateStyle('date', { align: 'right' })}
                    className={`px-2.5 py-1 rounded text-xs transition-colors flex items-center gap-1 ${
                      config.styles.date?.align === 'right'
                        ? 'bg-amber-100 text-amber-900 font-bold'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                    title="តម្រឹមស្តាំ"
                  >
                    <AlignRight className="w-3.5 h-3.5" />
                    <span>ស្តាំ</span>
                  </button>
                </div>
              </div>

              {/* LUNAR DATE (ចន្ទគតិ) */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5 cursor-pointer">
                    <Moon className="w-3.5 h-3.5 text-indigo-600" />
                    <span>កាលបរិច្ឆេទចន្ទគតិ (Lunar Date)</span>
                  </label>
                  <label className="flex items-center gap-1 text-[11px] text-slate-600 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.template.showLunarDate ?? true}
                      onChange={(e) => updateTemplate({ showLunarDate: e.target.checked })}
                      className="rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                    />
                    <span>បង្ហាញ</span>
                  </label>
                </div>

                {(config.template.showLunarDate ?? true) && (
                  <div className="space-y-2">
                    <input
                      type="text"
                      value={config.template.lunarDate ?? config.template.datePlace.split('\n')[0] ?? ''}
                      onChange={(e) =>
                        updateTemplate({
                          lunarDate: e.target.value,
                          datePlace: `${e.target.value}\n${config.template.solarDate ?? config.template.datePlace.split('\n')[1] ?? ''}`,
                        })
                      }
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs leading-relaxed focus:ring-2 focus:ring-amber-500 focus:outline-none font-medium"
                      placeholder="ថ្ងៃ.....................ខែ.................. ឆ្នាំមមី អដ្ឋស័ក ព.ស.២៥៧០"
                    />

                    {/* Quick Presets for Lunar Date */}
                    <div className="flex flex-wrap gap-1 text-[10px]">
                      {LUNAR_DATE_PRESETS.map((preset, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() =>
                            updateTemplate({
                              lunarDate: preset.value,
                              datePlace: `${preset.value}\n${config.template.solarDate ?? config.template.datePlace.split('\n')[1] ?? ''}`,
                            })
                          }
                          className="px-2 py-0.5 bg-white hover:bg-indigo-50 hover:text-indigo-900 border border-slate-200 hover:border-indigo-300 rounded text-slate-600 transition-colors"
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* SOLAR DATE (សុរិយគតិ) */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-bold text-slate-800 flex items-center gap-1.5 cursor-pointer">
                    <Sun className="w-3.5 h-3.5 text-amber-600" />
                    <span>កាលបរិច្ឆេទសុរិយគតិ (Solar Date)</span>
                  </label>
                  <label className="flex items-center gap-1 text-[11px] text-slate-600 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={config.template.showSolarDate ?? true}
                      onChange={(e) => updateTemplate({ showSolarDate: e.target.checked })}
                      className="rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                    />
                    <span>បង្ហាញ</span>
                  </label>
                </div>

                {(config.template.showSolarDate ?? true) && (
                  <div className="space-y-2">
                    <input
                      type="text"
                      value={config.template.solarDate ?? config.template.datePlace.split('\n')[1] ?? ''}
                      onChange={(e) =>
                        updateTemplate({
                          solarDate: e.target.value,
                          datePlace: `${config.template.lunarDate ?? config.template.datePlace.split('\n')[0] ?? ''}\n${e.target.value}`,
                        })
                      }
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs leading-relaxed focus:ring-2 focus:ring-amber-500 focus:outline-none font-medium"
                      placeholder=".................. ថ្ងៃទី.......... ខែ............. ឆ្នាំ២០២៦"
                    />

                    {/* Quick Presets for Solar Date */}
                    <div className="flex flex-wrap gap-1 text-[10px]">
                      {SOLAR_DATE_PRESETS.map((preset, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() =>
                            updateTemplate({
                              solarDate: preset.value,
                              datePlace: `${config.template.lunarDate ?? config.template.datePlace.split('\n')[0] ?? ''}\n${preset.value}`,
                            })
                          }
                          className="px-2 py-0.5 bg-white hover:bg-amber-50 hover:text-amber-900 border border-slate-200 hover:border-amber-300 rounded text-slate-600 transition-colors"
                        >
                          {preset.label}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Signatures configuration */}
              <div className="grid grid-cols-2 gap-3 pt-1">
                {/* Left signature */}
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-700">ហត្ថលេខាខាងឆ្វេង</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={config.template.showLeftSign}
                        onChange={(e) => updateTemplate({ showLeftSign: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className="w-8 h-4 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-amber-600"></div>
                    </label>
                  </div>
                  {config.template.showLeftSign && (
                    <>
                      <input
                        type="text"
                        value={config.template.signTitleLeft}
                        onChange={(e) => updateTemplate({ signTitleLeft: e.target.value })}
                        placeholder="បានឃើញ និងឯកភាព"
                        className="w-full px-2 py-1 text-xs border border-slate-300 rounded bg-white"
                      />
                      <input
                        type="text"
                        value={config.template.signRoleLeft}
                        onChange={(e) => updateTemplate({ signRoleLeft: e.target.value })}
                        placeholder="តួនាទី (ឧ. ប្រធានការិយាល័យ)"
                        className="w-full px-2 py-1 text-xs border border-slate-300 rounded bg-white"
                      />
                      <input
                        type="text"
                        value={config.template.signNameLeft || ''}
                        onChange={(e) => updateTemplate({ signNameLeft: e.target.value })}
                        placeholder="ឈ្មោះហត្ថលេខី (ស្រេចចិត្ត)"
                        className="w-full px-2 py-1 text-xs border border-slate-300 rounded bg-white"
                      />
                    </>
                  )}
                </div>

                {/* Right signature */}
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-700">ហត្ថលេខាខាងស្តាំ</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={config.template.showRightSign}
                        onChange={(e) => updateTemplate({ showRightSign: e.target.checked })}
                        className="sr-only peer"
                      />
                      <div className="w-8 h-4 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-amber-600"></div>
                    </label>
                  </div>
                  {config.template.showRightSign && (
                    <>
                      <input
                        type="text"
                        value={config.template.signRoleRight}
                        onChange={(e) => updateTemplate({ signRoleRight: e.target.value })}
                        placeholder="នាយកសាលា"
                        className="w-full px-2 py-1 text-xs border border-slate-300 rounded bg-white font-medium"
                      />
                      <input
                        type="text"
                        value={config.template.signNameRight || ''}
                        onChange={(e) => updateTemplate({ signNameRight: e.target.value })}
                        placeholder="ឈ្មោះហត្ថលេខី (ស្រេចចិត្ត)"
                        className="w-full px-2 py-1 text-xs border border-slate-300 rounded bg-white"
                      />
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* UNIQUE STUDENT QR CODE SECTION */}
            <div className="space-y-3 pt-2 border-t border-slate-200">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <QrCode className="w-3.5 h-3.5 text-amber-600" />
                  កូដ QR ផ្ទៀងផ្ទាត់សិស្ស (Unique Student QR Code)
                </h3>
                <label className="flex items-center gap-1.5 text-xs text-slate-700 cursor-pointer font-semibold">
                  <input
                    type="checkbox"
                    checked={config.template.showQrCode ?? true}
                    onChange={(e) => updateTemplate({ showQrCode: e.target.checked })}
                    className="rounded border-slate-300 text-amber-600 focus:ring-amber-500"
                  />
                  <span>បង្ហាញលើប័ណ្ណ</span>
                </label>
              </div>

              {(config.template.showQrCode ?? true) && (
                <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
                  {/* Position & Size */}
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="text-slate-600 font-medium block mb-1">ទីតាំង QR Code</label>
                      <select
                        value={config.template.qrCodePosition || 'bottom-left'}
                        onChange={(e) =>
                          updateTemplate({
                            qrCodePosition: e.target.value as 'bottom-left' | 'bottom-right' | 'bottom-center',
                          })
                        }
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs"
                      >
                        <option value="bottom-left">↙️ ជ្រុងឆ្វេងក្រោម (ស្តង់ដារ)</option>
                        <option value="bottom-center">⬇️ កណ្តាលក្រោម</option>
                        <option value="bottom-right">↘️ ជ្រុងស្តាំក្រោម</option>
                      </select>
                    </div>
                    <div>
                      <label className="text-slate-600 font-medium block mb-1">
                        ទំហំកូដ ({config.styles.qrCode?.size || 76}px)
                      </label>
                      <input
                        type="range"
                        min={50}
                        max={115}
                        value={config.styles.qrCode?.size || 76}
                        onChange={(e) =>
                          onChangeConfig({
                            ...config,
                            styles: {
                              ...config.styles,
                              qrCode: {
                                ...(config.styles.qrCode || { offsetY: 0, offsetX: 0, color: '#1e293b' }),
                                size: Number(e.target.value),
                              },
                            },
                          })
                        }
                        className="w-full accent-amber-600 mt-2"
                      />
                    </div>
                  </div>

                  {/* Caption / Label under QR code */}
                  <div className="pt-1 border-t border-slate-200">
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs text-slate-600 font-medium">ចំណងជើងខាងក្រោមកូដ QR</label>
                      <label className="flex items-center gap-1 text-[11px] text-slate-600 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={config.template.showQrCodeLabel ?? true}
                          onChange={(e) => updateTemplate({ showQrCodeLabel: e.target.checked })}
                          className="rounded border-slate-300 text-amber-600"
                        />
                        <span>បង្ហាញអក្សរ</span>
                      </label>
                    </div>
                    {(config.template.showQrCodeLabel ?? true) && (
                      <input
                        type="text"
                        value={config.template.qrCodeLabel ?? 'ស្កេនផ្ទៀងផ្ទាត់'}
                        onChange={(e) => updateTemplate({ qrCodeLabel: e.target.value })}
                        className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs"
                        placeholder="ឧ. ស្កេនផ្ទៀងផ្ទាត់"
                      />
                    )}
                  </div>

                  {/* QR Data Template & Presets */}
                  <div className="pt-1 border-t border-slate-200 space-y-1.5">
                    <div className="flex items-center justify-between">
                      <label className="text-xs text-slate-700 font-bold">ទម្រង់ទិន្នន័យ QR (Data Template)</label>
                      <span className="text-[10px] text-slate-400">ផ្អែកលើទិន្នន័យសិស្ស</span>
                    </div>

                    {/* Presets */}
                    <div className="flex flex-wrap gap-1 text-[10px]">
                      <button
                        type="button"
                        onClick={() => updateTemplate({ qrCodeText: DEFAULT_QR_URL_TEMPLATE })}
                        className="px-2 py-0.5 bg-white hover:bg-amber-50 hover:text-amber-900 border border-slate-200 hover:border-amber-300 rounded text-slate-700 transition-colors"
                      >
                        🌐 តំណភ្ជាប់ URL ក្រសួង
                      </button>
                      <button
                        type="button"
                        onClick={() => updateTemplate({ qrCodeText: DEFAULT_QR_TEXT_TEMPLATE })}
                        className="px-2 py-0.5 bg-white hover:bg-amber-50 hover:text-amber-900 border border-slate-200 hover:border-amber-300 rounded text-slate-700 transition-colors"
                      >
                        📋 ព័ត៌មានសិស្សជាអក្សរ
                      </button>
                      <button
                        type="button"
                        onClick={() => updateTemplate({ qrCodeText: DEFAULT_QR_JSON_TEMPLATE })}
                        className="px-2 py-0.5 bg-white hover:bg-amber-50 hover:text-amber-900 border border-slate-200 hover:border-amber-300 rounded text-slate-700 transition-colors font-mono"
                      >
                        💻 JSON
                      </button>
                    </div>

                    <textarea
                      rows={3}
                      value={config.template.qrCodeText || DEFAULT_QR_URL_TEMPLATE}
                      onChange={(e) => updateTemplate({ qrCodeText: e.target.value })}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-[11px] font-mono leading-relaxed focus:ring-2 focus:ring-amber-500 focus:outline-none"
                    />

                    {/* Quick tag chips */}
                    <div className="flex flex-wrap gap-1 text-[10px]">
                      {[
                        '{id}',
                        '{name}',
                        '{gender}',
                        '{dob}',
                        '{grade}',
                        '{rank}',
                        '{school}',
                        '{year}',
                      ].map((tag) => (
                        <button
                          key={tag}
                          type="button"
                          onClick={() =>
                            updateTemplate({
                              qrCodeText: (config.template.qrCodeText || '') + tag,
                            })
                          }
                          className="px-1.5 py-0.5 bg-slate-100 hover:bg-amber-100 hover:text-amber-900 rounded font-mono text-slate-600 transition-colors"
                        >
                          +{tag}
                        </button>
                      ))}
                    </div>

                    {/* Real-time Decoded Payload Preview for current student */}
                    <div className="mt-2 p-2 bg-amber-50/80 border border-amber-200 rounded-lg text-xs">
                      <div className="font-semibold text-amber-950 text-[11px] flex items-center justify-between">
                        <span>ទិន្នន័យ QR របស់សិស្ស {currentStudent.name} (#{currentStudent.id})៖</span>
                      </div>
                      <div className="mt-1 text-[10px] text-slate-700 font-mono break-all whitespace-pre-wrap max-h-16 overflow-y-auto bg-white/80 p-1.5 rounded border border-amber-100">
                        {generateStudentQrPayload(config.template.qrCodeText, currentStudent)}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* ===================== TAB 2: STYLES ===================== */}
        {activeTab === 'styles' && (
          <div className="space-y-5">
            {/* Title Style */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800">ចំណងជើងធំ (Title)</span>
                <input
                  type="color"
                  value={config.styles.title.color}
                  onChange={(e) => updateStyle('title', { color: e.target.value })}
                  className="w-6 h-6 rounded cursor-pointer border-0 p-0"
                />
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-slate-500">ទំហំអក្សរ ({config.styles.title.size}px)</label>
                  <input
                    type="range"
                    min={20}
                    max={54}
                    value={config.styles.title.size}
                    onChange={(e) => updateStyle('title', { size: Number(e.target.value) })}
                    className="w-full accent-amber-600"
                  />
                </div>
                <div>
                  <label className="text-slate-500">គម្លាតបញ្ឈរ Y ({config.styles.title.offsetY}px)</label>
                  <input
                    type="range"
                    min={-60}
                    max={40}
                    value={config.styles.title.offsetY}
                    onChange={(e) => updateStyle('title', { offsetY: Number(e.target.value) })}
                    className="w-full accent-amber-600"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs text-slate-500 block mb-1">ពុម្ពអក្សរ</label>
                <select
                  value={config.styles.title.font}
                  onChange={(e) => updateStyle('title', { font: e.target.value })}
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                >
                  {FONT_OPTIONS.map((font) => (
                    <option key={font.value} value={font.value}>
                      {font.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Subtitle Style */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800">ចំណងជើងរង (Subtitle)</span>
                <input
                  type="color"
                  value={config.styles.subtitle.color}
                  onChange={(e) => updateStyle('subtitle', { color: e.target.value })}
                  className="w-6 h-6 rounded cursor-pointer border-0 p-0"
                />
              </div>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-slate-500">ទំហំអក្សរ ({config.styles.subtitle.size}px)</label>
                  <input
                    type="range"
                    min={16}
                    max={36}
                    value={config.styles.subtitle.size}
                    onChange={(e) => updateStyle('subtitle', { size: Number(e.target.value) })}
                    className="w-full accent-amber-600"
                  />
                </div>
                <div>
                  <label className="text-slate-500">គម្លាតបញ្ឈរ Y ({config.styles.subtitle.offsetY}px)</label>
                  <input
                    type="range"
                    min={-60}
                    max={30}
                    value={config.styles.subtitle.offsetY}
                    onChange={(e) => updateStyle('subtitle', { offsetY: Number(e.target.value) })}
                    className="w-full accent-amber-600"
                  />
                </div>
              </div>
            </div>

            {/* Body Text Style */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800">តួអក្សរខ្លឹមសារ (Body Text)</span>
                <input
                  type="color"
                  value={config.styles.body.color}
                  onChange={(e) => updateStyle('body', { color: e.target.value })}
                  className="w-6 h-6 rounded cursor-pointer border-0 p-0"
                />
              </div>

              {/* Align & Indent in Style Tab */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-slate-500 block mb-1">ការតម្រឹម (Alignment)</label>
                  <div className="flex items-center bg-white border border-slate-300 rounded-lg p-0.5">
                    <button
                      type="button"
                      onClick={() => updateStyle('body', { align: 'left' })}
                      className={`flex-1 py-1 rounded text-center transition-colors ${
                        (config.styles.body?.align || 'left') !== 'center'
                          ? 'bg-amber-100 text-amber-900 font-bold'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                      title="តម្រឹមឆ្វេង"
                    >
                      ឆ្វេង
                    </button>
                    <button
                      type="button"
                      onClick={() => updateStyle('body', { align: 'center' })}
                      className={`flex-1 py-1 rounded text-center transition-colors ${
                        config.styles.body?.align === 'center'
                          ? 'bg-amber-100 text-amber-900 font-bold'
                          : 'text-slate-500 hover:text-slate-800'
                      }`}
                      title="តម្រឹមកណ្តាល"
                    >
                      កណ្តាល
                    </button>
                  </div>
                </div>

                <div>
                  <label className="text-slate-500 block mb-1">
                    ចូលបន្ទាត់ដំបូង ({config.styles.body?.indent ?? 48}px)
                  </label>
                  <input
                    type="range"
                    min={0}
                    max={100}
                    step={4}
                    value={config.styles.body?.indent ?? 48}
                    onChange={(e) => updateStyle('body', { indent: Number(e.target.value) })}
                    className="w-full accent-amber-600 mt-2"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-slate-500">ទំហំអក្សរ ({config.styles.body.size}px)</label>
                  <input
                    type="range"
                    min={14}
                    max={28}
                    value={config.styles.body.size}
                    onChange={(e) => updateStyle('body', { size: Number(e.target.value) })}
                    className="w-full accent-amber-600"
                  />
                </div>
                <div>
                  <label className="text-slate-500">គម្លាតបញ្ឈរ Y ({config.styles.body.offsetY}px)</label>
                  <input
                    type="range"
                    min={-50}
                    max={30}
                    value={config.styles.body.offsetY}
                    onChange={(e) => updateStyle('body', { offsetY: Number(e.target.value) })}
                    className="w-full accent-amber-600"
                  />
                </div>
              </div>
              <div>
                <label className="text-xs text-slate-500 block mb-1">ពុម្ពអក្សរខ្លឹមសារ</label>
                <select
                  value={config.styles.body.font}
                  onChange={(e) => updateStyle('body', { font: e.target.value })}
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                >
                  {FONT_OPTIONS.map((font) => (
                    <option key={font.value} value={font.value}>
                      {font.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Highlights Colors: Data Text, Rank Text & Cert Number */}
            <div className="p-3 bg-amber-50/60 border border-amber-200 rounded-xl space-y-3">
              <span className="text-xs font-bold text-amber-950 block">ពណ៌បន្លិចទិន្នន័យ, ចំណាត់ថ្នាក់ & លេខលិខិត</span>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
                <div className="flex items-center justify-between p-2 bg-white rounded-lg border border-slate-200">
                  <span className="text-[11px] font-medium text-slate-700">ពណ៌ទិន្នន័យ</span>
                  <input
                    type="color"
                    value={config.styles.dataText?.color || '#0000ff'}
                    onChange={(e) =>
                      onChangeConfig({
                        ...config,
                        styles: {
                          ...config.styles,
                          dataText: { ...config.styles.dataText, color: e.target.value },
                        },
                      })
                    }
                    className="w-6 h-6 rounded cursor-pointer border-0"
                  />
                </div>
                <div className="flex items-center justify-between p-2 bg-white rounded-lg border border-slate-200">
                  <span className="text-[11px] font-medium text-slate-700">ពណ៌ចំណាត់ថ្នាក់លេខ</span>
                  <input
                    type="color"
                    value={config.styles.rankText?.color || '#ff0000'}
                    onChange={(e) =>
                      onChangeConfig({
                        ...config,
                        styles: {
                          ...config.styles,
                          rankText: { ...config.styles.rankText, color: e.target.value },
                        },
                      })
                    }
                    className="w-6 h-6 rounded cursor-pointer border-0"
                  />
                </div>
                <div className="flex items-center justify-between p-2 bg-white rounded-lg border border-blue-200 bg-blue-50/30">
                  <div>
                    <span className="text-[11px] font-semibold text-blue-950 block">ពណ៌ទឹកប៊ិច (លេខលិខិត)</span>
                    <span className="text-[9px] text-blue-600 block">០២៦ ប.ស.រ.</span>
                  </div>
                  <input
                    type="color"
                    value={config.styles.certNumber?.color || '#1d4ed8'}
                    onChange={(e) =>
                      onChangeConfig({
                        ...config,
                        styles: {
                          ...config.styles,
                          certNumber: { ...config.styles.certNumber, color: e.target.value, bold: true },
                        },
                      })
                    }
                    className="w-6 h-6 rounded cursor-pointer border-0"
                    title="ពណ៌ទឹកប៊ិចលេខលិខិត"
                  />
                </div>
              </div>
            </div>

            {/* Layout Margins & Padding */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <span className="text-xs font-bold text-slate-800 block">
                គម្លាតស៊ុម និងគែមសន្លឹក (Border Margins)
              </span>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="text-slate-500">
                    គម្លាតពីលើ Top Margin ({config.styles.layout?.paddingTop ?? 125}px)
                  </label>
                  <input
                    type="range"
                    min={60}
                    max={180}
                    value={config.styles.layout?.paddingTop ?? 125}
                    onChange={(e) => updateLayout({ paddingTop: Number(e.target.value) })}
                    className="w-full accent-amber-600"
                  />
                  <div className="flex justify-between text-[10px] text-slate-400">
                    <span>ឡើងលើ</span>
                    <span>ចុះក្រោម (ការពារជាន់ក្បាច់)</span>
                  </div>
                </div>
                <div>
                  <label className="text-slate-500">
                    គម្លាតសងខាង Sides ({config.styles.layout?.paddingSides ?? 105}px)
                  </label>
                  <input
                    type="range"
                    min={60}
                    max={160}
                    value={config.styles.layout?.paddingSides ?? 105}
                    onChange={(e) => updateLayout({ paddingSides: Number(e.target.value) })}
                    className="w-full accent-amber-600"
                  />
                </div>
              </div>
            </div>

            {/* Header & Motto Styles */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <span className="text-xs font-bold text-slate-800 block">ក្បាលទំព័រ & បាវចនា</span>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="text-slate-500">ទំហំក្បាលទំព័រ ({config.styles.header.size}px)</label>
                  <input
                    type="range"
                    min={12}
                    max={26}
                    value={config.styles.header.size}
                    onChange={(e) => updateStyle('header', { size: Number(e.target.value) })}
                    className="w-full accent-amber-600"
                  />
                </div>
                <div>
                  <label className="text-slate-500">ទំហំបាវចនា ({config.styles.motto.size}px)</label>
                  <input
                    type="range"
                    min={12}
                    max={26}
                    value={config.styles.motto.size}
                    onChange={(e) => updateStyle('motto', { size: Number(e.target.value) })}
                    className="w-full accent-amber-600"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-3 text-xs pt-1 border-t border-slate-200">
                <div>
                  <label className="text-slate-500">
                    កម្ពស់ Y ក្បាលទំព័រ ({config.styles.header.offsetY || 0}px)
                  </label>
                  <input
                    type="range"
                    min={-40}
                    max={60}
                    value={config.styles.header.offsetY || 0}
                    onChange={(e) => updateStyle('header', { offsetY: Number(e.target.value) })}
                    className="w-full accent-amber-600"
                  />
                </div>
                <div>
                  <label className="text-slate-500">
                    កម្ពស់ Y បាវចនា ({config.styles.motto.offsetY || 0}px)
                  </label>
                  <input
                    type="range"
                    min={-40}
                    max={60}
                    value={config.styles.motto.offsetY || 0}
                    onChange={(e) => updateStyle('motto', { offsetY: Number(e.target.value) })}
                    className="w-full accent-amber-600"
                  />
                </div>
              </div>
            </div>

            {/* Date Style (Lunar & Solar Dates) */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800">
                  កាលបរិច្ឆេទចន្ទគតិ & សុរិយគតិ (Date Style)
                </span>
                <input
                  type="color"
                  value={config.styles.date?.color || '#1e293b'}
                  onChange={(e) => updateStyle('date', { color: e.target.value })}
                  className="w-6 h-6 rounded cursor-pointer border-0 p-0"
                />
              </div>

              {/* Align in Style Tab */}
              <div>
                <label className="text-slate-500 text-xs block mb-1">ការតម្រឹម (Alignment)</label>
                <div className="flex items-center bg-white border border-slate-300 rounded-lg p-0.5">
                  <button
                    type="button"
                    onClick={() => updateStyle('date', { align: 'left' })}
                    className={`flex-1 py-1 rounded text-xs text-center transition-colors flex items-center justify-center gap-1 ${
                      (config.styles.date?.align || 'left') === 'left'
                        ? 'bg-amber-100 text-amber-900 font-bold'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                    title="តម្រឹមឆ្វេង (ស្តង់ដារ)"
                  >
                    <AlignLeft className="w-3.5 h-3.5" />
                    <span>ឆ្វេង</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => updateStyle('date', { align: 'center' })}
                    className={`flex-1 py-1 rounded text-xs text-center transition-colors flex items-center justify-center gap-1 ${
                      config.styles.date?.align === 'center'
                        ? 'bg-amber-100 text-amber-900 font-bold'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                    title="តម្រឹមកណ្តាល"
                  >
                    <AlignCenter className="w-3.5 h-3.5" />
                    <span>កណ្តាល</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => updateStyle('date', { align: 'right' })}
                    className={`flex-1 py-1 rounded text-xs text-center transition-colors flex items-center justify-center gap-1 ${
                      config.styles.date?.align === 'right'
                        ? 'bg-amber-100 text-amber-900 font-bold'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                    title="តម្រឹមស្តាំ"
                  >
                    <AlignRight className="w-3.5 h-3.5" />
                    <span>ស្តាំ</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>
                  <label className="text-slate-500">
                    ទំហំអក្សរ ({config.styles.date?.size || 14}px)
                  </label>
                  <input
                    type="range"
                    min={11}
                    max={20}
                    value={config.styles.date?.size || 14}
                    onChange={(e) => updateStyle('date', { size: Number(e.target.value) })}
                    className="w-full accent-amber-600"
                  />
                </div>
                <div>
                  <label className="text-slate-500">
                    គម្លាតបញ្ឈរ Y ({config.styles.date?.offsetY || 0}px)
                  </label>
                  <input
                    type="range"
                    min={-30}
                    max={30}
                    value={config.styles.date?.offsetY || 0}
                    onChange={(e) => updateStyle('date', { offsetY: Number(e.target.value) })}
                    className="w-full accent-amber-600"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs text-slate-500 block mb-1">ពុម្ពអក្សរកាលបរិច្ឆេទ</label>
                <select
                  value={config.styles.date?.font || 'Khmer OS Battambang'}
                  onChange={(e) => updateStyle('date', { font: e.target.value })}
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-lg"
                >
                  {FONT_OPTIONS.map((font) => (
                    <option key={font.value} value={font.value}>
                      {font.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>
        )}

        {/* ===================== TAB 3: GRAPHICS & SEALS ===================== */}
        {activeTab === 'graphics' && (
          <div className="space-y-5">
            {/* Background Image & Hue */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Image className="w-4 h-4 text-amber-600" />
                  រូបភាពផ្ទៃខាងក្រោយ & ក្បាច់ស៊ុម
                </span>
              </div>

              {/* Background Preset Selection */}
              <div>
                <label className="block text-xs text-slate-600 font-medium mb-1.5">
                  ជ្រើសរើសម៉ូដស៊ុមប័ណ្ណសរសើរ
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {BACKGROUND_PRESETS.map((preset) => {
                    const isSelected = config.bgUrl === preset.url;
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => onChangeConfig({ ...config, bgUrl: preset.url })}
                        className={`p-2 rounded-lg border text-left text-xs transition-all relative ${
                          isSelected
                            ? 'border-amber-600 bg-amber-50 text-amber-950 font-semibold ring-1 ring-amber-600'
                            : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span>{preset.name}</span>
                          {isSelected && <Check className="w-3.5 h-3.5 text-amber-600 shrink-0" />}
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Upload Custom Background */}
              <div>
                <label className="block text-xs text-slate-600 font-medium mb-1">
                  ឬផ្ទុកឡើងរូបភាពផ្ទៃខាងក្រោយផ្ទាល់ខ្លួន (Background Image)
                </label>
                <div className="flex items-center gap-2">
                  <label className="flex-1 flex items-center justify-center gap-2 px-3 py-2 bg-white border border-dashed border-slate-300 hover:border-amber-500 rounded-lg cursor-pointer text-xs font-medium text-slate-700 transition-colors">
                    <Upload className="w-4 h-4 text-amber-600" />
                    <span>ជ្រើសរើសរូបភាពពីកុំព្យូទ័រ / ទូរសព្ទ...</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) =>
                        handleImageUpload(e, (url) => onChangeConfig({ ...config, bgUrl: url }))
                      }
                    />
                  </label>
                </div>
              </div>

              {/* Hue & Brightness controls */}
              <div className="grid grid-cols-2 gap-3 text-xs pt-1">
                <div>
                  <label className="text-slate-600 font-medium">
                    កែប្រែពណ៌ផ្ទៃ Hue ({config.bgHue || 0}°)
                  </label>
                  <input
                    type="range"
                    min={-180}
                    max={180}
                    value={config.bgHue || 0}
                    onChange={(e) => onChangeConfig({ ...config, bgHue: Number(e.target.value) })}
                    className="w-full accent-amber-600"
                  />
                </div>
                <div>
                  <label className="text-slate-600 font-medium">
                    ពន្លឺ Brightness ({config.bgBrightness || 100}%)
                  </label>
                  <input
                    type="range"
                    min={60}
                    max={140}
                    value={config.bgBrightness || 100}
                    onChange={(e) =>
                      onChangeConfig({ ...config, bgBrightness: Number(e.target.value) })
                    }
                    className="w-full accent-amber-600"
                  />
                </div>
              </div>
            </div>

            {/* Official Stamp (ត្រាផ្លូវការ) */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Stamp className="w-4 h-4 text-red-600" />
                  ត្រាផ្លូវការសាលា (Official Stamp)
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.template.showStamp}
                    onChange={(e) => updateTemplate({ showStamp: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-8 h-4 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-amber-600"></div>
                </label>
              </div>

              {config.template.showStamp && (
                <div className="space-y-3 pt-1">
                  <div>
                    <label className="block text-xs text-slate-600 font-medium mb-1">
                      ផ្ទុកឡើងរូបភាពត្រាផ្ទាល់ខ្លួន
                    </label>
                    <label className="flex items-center justify-center gap-2 px-3 py-1.5 bg-white border border-dashed border-slate-300 hover:border-red-400 rounded-lg cursor-pointer text-xs font-medium text-slate-700">
                      <Upload className="w-3.5 h-3.5 text-red-600" />
                      <span>ជ្រើសរើសរូបត្រា (.PNG មានផ្ទៃថ្លា)</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) =>
                          handleImageUpload(e, (url) => updateTemplate({ stampImage: url }))
                        }
                      />
                    </label>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="text-slate-500">
                        ទំហំត្រា ({config.styles.stamp?.width || 120}px)
                      </label>
                      <input
                        type="range"
                        min={70}
                        max={180}
                        value={config.styles.stamp?.width || 120}
                        onChange={(e) =>
                          onChangeConfig({
                            ...config,
                            styles: {
                              ...config.styles,
                              stamp: {
                                ...config.styles.stamp!,
                                width: Number(e.target.value),
                              },
                            },
                          })
                        }
                        className="w-full accent-amber-600"
                      />
                    </div>
                    <div>
                      <label className="text-slate-500">
                        មុំបង្វិល ({config.styles.stamp?.rotation || -8}°)
                      </label>
                      <input
                        type="range"
                        min={-45}
                        max={45}
                        value={config.styles.stamp?.rotation || -8}
                        onChange={(e) =>
                          onChangeConfig({
                            ...config,
                            styles: {
                              ...config.styles,
                              stamp: {
                                ...config.styles.stamp!,
                                rotation: Number(e.target.value),
                              },
                            },
                          })
                        }
                        className="w-full accent-amber-600"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="text-slate-500">
                        ទីតាំង X ({config.styles.stamp?.offsetX || 20}px)
                      </label>
                      <input
                        type="range"
                        min={-150}
                        max={150}
                        value={config.styles.stamp?.offsetX || 20}
                        onChange={(e) =>
                          onChangeConfig({
                            ...config,
                            styles: {
                              ...config.styles,
                              stamp: {
                                ...config.styles.stamp!,
                                offsetX: Number(e.target.value),
                              },
                            },
                          })
                        }
                        className="w-full accent-amber-600"
                      />
                    </div>
                    <div>
                      <label className="text-slate-500">
                        ទីតាំង Y ({config.styles.stamp?.offsetY || 10}px)
                      </label>
                      <input
                        type="range"
                        min={-80}
                        max={80}
                        value={config.styles.stamp?.offsetY || 10}
                        onChange={(e) =>
                          onChangeConfig({
                            ...config,
                            styles: {
                              ...config.styles,
                              stamp: {
                                ...config.styles.stamp!,
                                offsetY: Number(e.target.value),
                              },
                            },
                          })
                        }
                        className="w-full accent-amber-600"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Rank Medal (មេដាយកិត្តិយស) */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-amber-600" />
                  មេដាយកិត្តិយស (Honor Medal Badge)
                </span>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={config.template.showRankMedal}
                    onChange={(e) => updateTemplate({ showRankMedal: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-8 h-4 bg-slate-200 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-3 after:w-3 after:transition-all peer-checked:bg-amber-600"></div>
                </label>
              </div>

              {config.template.showRankMedal && (
                <div className="space-y-3 pt-1">
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="text-slate-500">
                        ទំហំមេដាយ ({config.styles.rankMedal?.width || 85}px)
                      </label>
                      <input
                        type="range"
                        min={50}
                        max={140}
                        value={config.styles.rankMedal?.width || 85}
                        onChange={(e) => updateStyle('rankMedal', { width: Number(e.target.value) })}
                        className="w-full accent-amber-600"
                      />
                    </div>
                    <div>
                      <label className="text-slate-500">
                        ទំហំលេខក្នុងមេដាយ ({config.styles.rankMedalText?.size || 38}px)
                      </label>
                      <input
                        type="range"
                        min={20}
                        max={60}
                        value={config.styles.rankMedalText?.size || 38}
                        onChange={(e) =>
                          updateStyle('rankMedalText', { size: Number(e.target.value) })
                        }
                        className="w-full accent-amber-600"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <label className="text-slate-500">
                        ទីតាំង X ({config.styles.rankMedal?.offsetX || -60}px)
                      </label>
                      <input
                        type="range"
                        min={-200}
                        max={100}
                        value={config.styles.rankMedal?.offsetX || -60}
                        onChange={(e) =>
                          updateStyle('rankMedal', { offsetX: Number(e.target.value) })
                        }
                        className="w-full accent-amber-600"
                      />
                    </div>
                    <div>
                      <label className="text-slate-500">
                        ទីតាំង Y ({config.styles.rankMedal?.offsetY || -35}px)
                      </label>
                      <input
                        type="range"
                        min={-150}
                        max={100}
                        value={config.styles.rankMedal?.offsetY || -35}
                        onChange={(e) =>
                          updateStyle('rankMedal', { offsetY: Number(e.target.value) })
                        }
                        className="w-full accent-amber-600"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Central Watermark & Logo */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-3">
              <span className="text-xs font-bold text-slate-800 block">
                និមិត្តសញ្ញា (Logo) & Watermark បន្ថែម
              </span>
              <div>
                <label className="block text-xs text-slate-600 font-medium mb-1">
                  Logo ក្បាលទំព័រខាងលើ (School / Ministry Logo)
                </label>
                <div className="flex items-center gap-2">
                  <label className="flex-1 flex items-center justify-center gap-2 px-3 py-1.5 bg-white border border-dashed border-slate-300 rounded-lg cursor-pointer text-xs font-medium text-slate-700">
                    <Upload className="w-3.5 h-3.5 text-amber-600" />
                    <span>{config.template.logoTop ? 'ប្តូរ Logo' : 'ផ្ទុកឡើង Logo'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) =>
                        handleImageUpload(e, (url) => updateTemplate({ logoTop: url }))
                      }
                    />
                  </label>
                  {config.template.logoTop && (
                    <button
                      type="button"
                      onClick={() => updateTemplate({ logoTop: null })}
                      className="p-1.5 text-red-600 hover:bg-red-50 rounded"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              <div>
                <label className="block text-xs text-slate-600 font-medium mb-1">
                  រូបថតសិស្ស (Student Photo)
                </label>
                <div className="flex items-center gap-2">
                  <label className="flex-1 flex items-center justify-center gap-2 px-3 py-1.5 bg-white border border-dashed border-slate-300 rounded-lg cursor-pointer text-xs font-medium text-slate-700">
                    <Upload className="w-3.5 h-3.5 text-amber-600" />
                    <span>{config.template.studentPhoto ? 'ប្តូររូបថត' : 'ផ្ទុកឡើងរូបថតសិស្ស'}</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) =>
                        handleImageUpload(e, (url) => updateTemplate({ studentPhoto: url }))
                      }
                    />
                  </label>
                  {config.template.studentPhoto && (
                    <button
                      type="button"
                      onClick={() => updateTemplate({ studentPhoto: null })}
                      className="p-1.5 text-red-600 hover:bg-red-50 rounded"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ===================== TAB 4: BATCH STUDENTS ===================== */}
        {activeTab === 'students' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  បញ្ជីសិស្សទាំងអស់ ({students.length} នាក់)
                </h3>
                <p className="text-xs text-slate-500">ចុចលើសិស្សដើម្បីមើល និងកែសម្រួលប័ណ្ណសរសើរ</p>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => {
                    onChangeStudents(SAMPLE_STUDENTS);
                    onSelectStudent(0);
                  }}
                  title="ផ្ទុកបញ្ជីសិស្ស ៤៩នាក់ ពីសាលាបឋមសិក្សា រោគ"
                  className="px-2.5 py-1.5 bg-amber-50 hover:bg-amber-100 border border-amber-300 text-amber-900 rounded-lg text-xs font-semibold shadow-2xs transition-colors flex items-center gap-1"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  <span>សិស្ស ៤៩នាក់</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const updated = students.map((s, idx) => ({
                      ...s,
                      certNumber: toKhmerDigits(String(26 + idx).padStart(3, '0')),
                    }));
                    onChangeStudents(updated);
                  }}
                  title="រៀបចំលេខលិខិតចាប់ពីលេខ ០២៦ ប.ស.រ."
                  className="px-2.5 py-1.5 bg-blue-50 hover:bg-blue-100 border border-blue-300 text-blue-900 rounded-lg text-xs font-semibold shadow-2xs transition-colors flex items-center gap-1"
                >
                  <Hash className="w-3.5 h-3.5 text-blue-600" />
                  <span>លេខ ០២៦...</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const newStd: StudentData = {
                      id: `ROK-${students.length + 1}`,
                      name: 'សិស្សថ្មី',
                      gender: 'ប្រុស',
                      grade: currentStudent.grade || '២ខ',
                      school: currentStudent.school || 'សាលាបឋមសិក្សា រោគ',
                      rank: toKhmerDigits(students.length + 1),
                      year: currentStudent.year || '២០២៥-២០២៦',
                    };
                    onChangeStudents([...students, newStd]);
                    onSelectStudent(students.length);
                  }}
                  className="flex items-center gap-1 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-xs font-semibold shadow-sm transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>បន្ថែម</span>
                </button>
              </div>
            </div>

            {/* Student List Cards */}
            <div className="space-y-2 max-h-[380px] overflow-y-auto pr-1">
              {students.map((std, index) => {
                const isActive = index === activeStudentIndex;
                return (
                  <div
                    key={std.id || index}
                    onClick={() => onSelectStudent(index)}
                    className={`p-3 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                      isActive
                        ? 'bg-amber-50/90 border-amber-400 shadow-sm ring-1 ring-amber-400'
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center space-x-3">
                      <div
                        className={`w-8 h-8 rounded-full flex items-center justify-center font-moul text-xs ${
                          isActive
                            ? 'bg-amber-600 text-white font-bold'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {std.rank || index + 1}
                      </div>
                      <div>
                        <div className="font-semibold text-sm text-slate-900 flex items-center gap-2">
                          <span>{std.name || '(គ្មានឈ្មោះ)'}</span>
                          <span className="text-[10px] px-1.5 py-0.2 bg-slate-100 text-slate-600 rounded">
                            {std.gender}
                          </span>
                        </div>
                        <div className="text-xs text-slate-500 flex items-center gap-1.5 flex-wrap">
                          <span>ថ្នាក់ទី {std.grade} | លេខ {std.rank}</span>
                          <span className="text-[10px] font-semibold text-blue-700 bg-blue-50 px-1 py-0.2 rounded border border-blue-200">
                            លេខ {std.certNumber || toKhmerDigits(String(26 + index).padStart(3, '0'))} ប.ស.រ.
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-1" onClick={(e) => e.stopPropagation()}>
                      {students.length > 1 && (
                        <button
                          type="button"
                          onClick={() => {
                            const filtered = students.filter((_, i) => i !== index);
                            onChangeStudents(filtered);
                            if (activeStudentIndex >= filtered.length) {
                              onSelectStudent(filtered.length - 1);
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="លុបសិស្សនេះ"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Quick Batch Actions */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2 text-xs">
              <span className="font-bold text-slate-700 block">សកម្មភាពបញ្ជីរហ័ស</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    // Normalize all ranks to Khmer numbers
                    const updated = students.map((s, idx) => ({
                      ...s,
                      rank: toKhmerDigits(s.rank || idx + 1),
                    }));
                    onChangeStudents(updated);
                  }}
                  className="px-2.5 py-1.5 bg-white border border-slate-200 hover:bg-slate-100 rounded text-slate-700 font-medium"
                >
                  បំប្លែងលេខខ្មែរទាំងអស់ (១,២,៣...)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const csvContent =
                      'name,gender,grade,rank,school,year\n' +
                      students
                        .map(
                          (s) =>
                            `"${s.name}","${s.gender}","${s.grade}","${s.rank}","${s.school}","${s.year}"`
                        )
                        .join('\n');
                    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                    const url = URL.createObjectURL(blob);
                    const link = document.createElement('a');
                    link.setAttribute('href', url);
                    link.setAttribute('download', 'students_list.csv');
                    link.click();
                  }}
                  className="px-2.5 py-1.5 bg-white border border-slate-200 hover:bg-slate-100 rounded text-slate-700 font-medium"
                >
                  ទាញយក CSV សិស្ស
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ===================== TAB 5: PRESETS & JSON ===================== */}
        {activeTab === 'presets' && (
          <div className="space-y-4">
            <div>
              <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                គំរូប័ណ្ណសរសើរផ្លូវការ (Official Presets)
              </h3>
              <div className="space-y-2.5">
                {PRESET_TEMPLATES.map((preset) => (
                  <div
                    key={preset.id}
                    onClick={() => handleApplyPreset(preset)}
                    className="p-3 bg-white hover:bg-amber-50/70 border border-slate-200 hover:border-amber-300 rounded-xl cursor-pointer transition-all space-y-1 shadow-2xs"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-semibold text-xs text-slate-900">
                        {preset.nameKhmer}
                      </span>
                      <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded font-medium">
                        {preset.badgeLabel}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 leading-snug">{preset.description}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* JSON Import & Export */}
            <div className="pt-3 border-t border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
                  ការកំណត់ JSON (Template & Styles)
                </h3>
                <button
                  type="button"
                  onClick={handleCopyConfigJson}
                  className="text-xs text-amber-700 hover:text-amber-800 font-medium flex items-center gap-1"
                >
                  {copiedJson ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedJson ? 'បានចម្លង!' : 'ចម្លង JSON'}</span>
                </button>
              </div>

              <div>
                <label className="text-xs text-slate-600 block mb-1">
                  បិទភ្ជាប់ (Paste) JSON ដើម្បីអនុវត្តការកំណត់៖
                </label>
                <textarea
                  rows={4}
                  value={jsonInput}
                  onChange={(e) => setJsonInput(e.target.value)}
                  placeholder='{"template": { ... }, "styles": { ... }}'
                  className="w-full p-2 text-xs font-mono bg-slate-900 text-slate-100 rounded-lg focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
                {jsonError && <p className="text-xs text-red-500 mt-1">{jsonError}</p>}
                <button
                  type="button"
                  onClick={handleApplyJson}
                  className="mt-2 w-full py-1.5 bg-slate-800 hover:bg-slate-700 text-white rounded-lg text-xs font-medium transition-colors"
                >
                  អនុវត្តទិន្នន័យ JSON
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
