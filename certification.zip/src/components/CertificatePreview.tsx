import React from 'react';
import { CertificateConfig, StudentData } from '../types/certificate';
import { getFontFamilyCss } from '../constants/defaultConfig';
import { interpolateText, renderInterpolatedRichText } from '../utils/certificateRenderer';
import { toKhmerDigits } from '../utils/khmerNumbers';
import { StudentQRCode } from './StudentQRCode';
import { generateStudentQrPayload } from '../utils/qrCodeHelper';

interface CertificatePreviewProps {
  config: CertificateConfig;
  student: StudentData;
  scale?: number;
  className?: string;
  id?: string;
  isPrintVersion?: boolean;
  studentIndex?: number;
}

export const CertificatePreview = React.forwardRef<HTMLDivElement, CertificatePreviewProps>(
  ({ config, student, scale = 1, className = '', id = 'certificate-canvas', isPrintVersion = false, studentIndex = 0 }, ref) => {
    const { template, styles, bgUrl, bgHue, bgBrightness = 100 } = config;

    // Filter styles for background image
    const bgFilter = `hue-rotate(${bgHue || 0}deg) brightness(${bgBrightness || 100}%)`;

    // Process school name placeholder in header/subtitle
    const schoolName = student.school || 'សាលាបឋមសិក្សា​ រោគ';

    const headerLines = template.header
      ? interpolateText(template.header, student).split('\n')
      : [];

    const mottoLines = template.motto ? template.motto.split('\n') : [];
    const wishesLines = template.wishes
      ? interpolateText(template.wishes, student).split('\n')
      : [];

    const datePlaceLines = React.useMemo(() => {
      const hasSpecificDates =
        template.lunarDate !== undefined || template.solarDate !== undefined;

      if (hasSpecificDates) {
        const lines: string[] = [];
        if ((template.showLunarDate ?? true) && template.lunarDate) {
          lines.push(interpolateText(template.lunarDate, student));
        }
        if ((template.showSolarDate ?? true) && template.solarDate) {
          lines.push(interpolateText(template.solarDate, student));
        }
        return lines;
      }

      return template.datePlace
        ? interpolateText(template.datePlace, student).split('\n')
        : [];
    }, [
      template.datePlace,
      template.lunarDate,
      template.solarDate,
      template.showLunarDate,
      template.showSolarDate,
      student,
    ]);

    const qrPayload = React.useMemo(() => {
      return generateStudentQrPayload(template.qrCodeText, student);
    }, [template.qrCodeText, student]);

    const paddingTop = styles.layout?.paddingTop ?? 125;
    const paddingSides = styles.layout?.paddingSides ?? 105;
    const paddingBottom = styles.layout?.paddingBottom ?? 80;

    const certNo =
      student.certNumber ||
      toKhmerDigits(String(26 + (studentIndex ?? 0)).padStart(3, '0'));
    const certColor = styles.certNumber?.color || '#1d4ed8'; // ពណ៌ទឹកប៊ិច (pen blue ink)

    const isCertNumberLine = (line: string) => {
      if (!line) return false;
      return (
        line.includes('{certNo}') ||
        line.includes('{certNumber}') ||
        /លេខ\s*[:៖]/.test(line) ||
        line.includes('ប.ស.រ.') ||
        line.includes('ប០')
      );
    };

    const renderHeaderLine = (line: string): React.ReactNode => {
      if (!line) return null;
      if (template.showCertNumber === false && isCertNumberLine(line)) {
        return null;
      }

      // Check if line contains certificate number or placeholder or dots pattern
      if (isCertNumberLine(line)) {
        // 1. Repair any corrupted pattern like "ប០២៦ស០២៦រ០២៦" or similar
        let clean = line.replace(/ប[០-៩0-9\s]*ស[០-៩0-9\s]*រ[០-៩0-9\s]*/g, 'ប.ស.រ.');

        // 2. Replace placeholders or leader dots (only match 2 or more dots to protect single periods)
        if (clean.includes('{certNo}')) {
          clean = clean.replace(/\{certNo\}/g, certNo);
        } else if (clean.includes('{certNumber}')) {
          clean = clean.replace(/\{certNumber\}/g, certNo);
        } else if (/[…]{2,}|\.{2,}/.test(clean)) {
          clean = clean.replace(/[…]{2,}|\.{2,}/g, certNo);
        } else if (/លេខ\s*[:៖]?\s*[០-៩0-9]+/i.test(clean)) {
          clean = clean.replace(/(លេខ\s*[:៖]?\s*)[០-៩0-9]+/i, `$1${certNo}`);
        }

        // 3. Ensure suffix "ប.ស.រ." is present
        if (!clean.includes('ប.ស.រ.')) {
          clean = `${clean.trim()} ប.ស.រ.`;
        }

        // 4. Split prefix "លេខ : " or "លេខ ៖ " from value "០២៦ ប.ស.រ."
        const match = clean.match(/^(.*?លេខ\s*[:៖]?\s*)(.*)$/);
        if (match) {
          const prefix = match[1];
          const certValue = match[2];
          return (
            <span>
              <span>{prefix}</span>
              <span
                className="font-bold tracking-wider inline-block ml-0.5"
                style={{
                  color: certColor,
                  fontFamily: styles.certNumber?.font
                    ? getFontFamilyCss(styles.certNumber.font)
                    : undefined,
                  fontSize: styles.certNumber?.size ? `${styles.certNumber.size}px` : undefined,
                }}
              >
                {certValue}
              </span>
            </span>
          );
        }

        return (
          <span className="font-bold tracking-wider" style={{ color: certColor }}>
            {clean}
          </span>
        );
      }

      return renderInterpolatedRichText(line, student, styles);
    };

    return (
      <div
        style={{
          transform: isPrintVersion ? 'none' : `scale(${scale})`,
          transformOrigin: 'top center',
        }}
        className={`transition-transform duration-150 ${className}`}
      >
        <div
          ref={ref}
          id={id}
          className="relative bg-white text-slate-900 select-none overflow-hidden certificate-canvas"
          style={{
            // Standard A4 Landscape aspect ratio: 297mm x 210mm (~1.414).
            // Base resolution in pixels: 1050px width x 742px height for crisp preview & export
            width: '1050px',
            height: '742px',
            boxSizing: 'border-box',
          }}
        >
          {/* Background Image / Border */}
          {bgUrl && (
            <div
              className="absolute inset-0 pointer-events-none z-0 bg-contain bg-center bg-no-repeat"
              style={{
                backgroundImage: `url(${bgUrl})`,
                filter: bgFilter,
              }}
            />
          )}

          {/* Central Watermark (if provided) */}
          {template.watermark && (
            <div
              className="absolute pointer-events-none z-0"
              style={{
                top: `calc(50% + ${styles.watermark?.offsetY || 0}px)`,
                left: `calc(50% + ${styles.watermark?.offsetX || 0}px)`,
                transform: 'translate(-50%, -50%)',
                width: `${styles.watermark?.width || 350}px`,
                opacity: styles.watermark?.opacity ?? 0.15,
              }}
            >
              <img
                src={template.watermark}
                alt="watermark"
                className="w-full h-auto object-contain"
              />
            </div>
          )}

          {/* Optional Text Watermark */}
          {template.showTextWatermark && template.textWatermarkContent && (
            <div
              className="absolute pointer-events-none z-0 select-none font-moul tracking-wide"
              style={{
                top: `calc(45% + ${styles.textWatermark?.offsetY || 0}px)`,
                left: `calc(48% + ${styles.textWatermark?.offsetX || 0}px)`,
                transform: 'translate(-50%, -50%) rotate(-20deg)',
                fontSize: '44px',
                color: 'rgba(14, 165, 233, 0.08)',
                whiteSpace: 'nowrap',
              }}
            >
              {template.textWatermarkContent}
            </div>
          )}

          {/* Inner Content Container */}
          <div
            className="relative z-10 w-full h-full flex flex-col justify-between"
            style={{
              padding: `${paddingTop}px ${paddingSides}px ${paddingBottom}px ${paddingSides}px`,
            }}
          >
            {/* TOP BAR: Left Header & Right Motto */}
            <div className="flex justify-between items-start w-full relative">
              {/* Header (Left) */}
              <div
                className="font-moul leading-snug tracking-wide max-w-[490px]"
                style={{
                  textAlign: (styles.header?.align || 'left') as any,
                  fontFamily: getFontFamilyCss(styles.header?.font || 'Khmer OS Muol Light'),
                  fontSize: `${styles.header?.size || 14}px`,
                  color: styles.header?.color || '#000000',
                  transform: `translate(${styles.header?.offsetX || 0}px, ${styles.header?.offsetY || 0}px)`,
                }}
              >
                {template.showLogoTop && template.logoTop && (
                  <div
                    className="mb-2 flex"
                    style={{
                      justifyContent:
                        styles.header?.align === 'center'
                          ? 'center'
                          : styles.header?.align === 'right'
                            ? 'flex-end'
                            : 'flex-start',
                    }}
                  >
                    <img
                      src={template.logoTop}
                      alt="Logo"
                      style={{
                        width: `${styles.logoTop?.width || 80}px`,
                        transform: `translate(${styles.logoTop?.offsetX || 0}px, ${styles.logoTop?.offsetY || 0}px)`,
                      }}
                      className="object-contain"
                    />
                  </div>
                )}
                {headerLines.map((line, i) => {
                  const rendered = renderHeaderLine(line);
                  if (rendered === null) return null;
                  return (
                    <div key={i} className="py-0.5 whitespace-nowrap">
                      {rendered}
                    </div>
                  );
                })}
              </div>

              {/* Motto (Right) */}
              <div
                className="text-center font-moul leading-snug max-w-[340px]"
                style={{
                  fontFamily: getFontFamilyCss(styles.motto?.font || 'Khmer OS Muol Light'),
                  fontSize: `${styles.motto?.size || 16}px`,
                  color: styles.motto?.color || '#000000',
                  transform: `translate(${styles.motto?.offsetX || 0}px, ${styles.motto?.offsetY || 0}px)`,
                }}
              >
                {mottoLines.map((line, i) => (
                  <div key={i} className="py-0.5 tracking-wider">
                    {line}
                  </div>
                ))}
                {template.mottoDecor && (
                  <div className="text-sm tracking-widest mt-1 text-amber-700/80 font-normal">
                    {template.mottoDecor}
                  </div>
                )}
              </div>
            </div>

            {/* CENTER TITLE & SUBTITLE */}
            <div className="text-center my-auto flex flex-col items-center justify-center">
              {/* Main Title: បណ្ណសរសើរ */}
              {(template.showTitle ?? true) && (
                <h1
                  className="font-moul tracking-wide font-black"
                  style={{
                    fontFamily: getFontFamilyCss(styles.title?.font || 'Khmer OS Muol Light'),
                    fontSize: `${styles.title?.size || 36}px`,
                    color: styles.title?.color || '#ff0000',
                    transform: `translate(${styles.title?.offsetX || 0}px, ${styles.title?.offsetY || 0}px)`,
                    textShadow: '0 1px 1px rgba(0,0,0,0.08)',
                  }}
                >
                  {template.title}
                </h1>
              )}

              {/* Subtitle: នាយកវិទ្យាល័យ... */}
              {(template.showSubtitle ?? true) && (
                <h2
                  className="font-moul tracking-normal font-semibold mt-1"
                  style={{
                    fontFamily: getFontFamilyCss(styles.subtitle?.font || 'Khmer OS Muol Light'),
                    fontSize: `${styles.subtitle?.size || 24}px`,
                    color: styles.subtitle?.color || '#0000ff',
                    transform: `translate(${styles.subtitle?.offsetX || 0}px, ${styles.subtitle?.offsetY || 0}px)`,
                  }}
                >
                  {interpolateText(template.subtitle, student)}
                </h2>
              )}

              {/* Body Text */}
              <div
                className="w-full mt-3 leading-loose tracking-wide"
                style={{
                  textAlign: styles.body?.align === 'center' ? 'center' : 'left',
                  fontFamily: getFontFamilyCss(styles.body?.font || 'Khmer OS Battambang'),
                  fontSize: `${styles.body?.size || 19}px`,
                  color: styles.body?.color || '#000000',
                  transform: `translate(${styles.body?.offsetX || 0}px, ${styles.body?.offsetY || 0}px)`,
                }}
              >
                {/* Intro Line & Description with First-line Indent */}
                <p
                  className="my-1.5 leading-relaxed text-slate-900"
                  style={{
                    textIndent: `${styles.body?.indent ?? 48}px`,
                    textAlign: styles.body?.align === 'center' ? 'center' : 'left',
                  }}
                >
                  {renderInterpolatedRichText(template.studentIntro, student, styles)}
                  {template.description && (
                    <> {renderInterpolatedRichText(template.description, student, styles)}</>
                  )}
                </p>

                {/* Wishes Line(s) with First-line Indent */}
                <div
                  className="mt-2.5 text-base text-slate-800 leading-relaxed font-normal"
                  style={{
                    textAlign: styles.body?.align === 'center' ? 'center' : 'left',
                  }}
                >
                  {wishesLines.map((line, i) => (
                    <p
                      key={i}
                      className="my-0.5"
                      style={{
                        textIndent: `${styles.body?.indent ?? 48}px`,
                        textAlign: styles.body?.align === 'center' ? 'center' : 'left',
                      }}
                    >
                      {line}
                    </p>
                  ))}
                </div>
              </div>
            </div>

            {/* Rank Medal / Badge (Floating) */}
            {template.showRankMedal && (
              <div
                className="absolute pointer-events-none select-none flex flex-col items-center justify-center"
                style={{
                  top: `calc(48% + ${styles.rankMedal?.offsetY || -50}px)`,
                  left: `calc(18% + ${styles.rankMedal?.offsetX || -70}px)`,
                  width: `${styles.rankMedal?.width || 90}px`,
                  zIndex: 20,
                }}
              >
                {template.rankMedalImage ? (
                  <div className="relative flex flex-col items-center">
                    <img
                      src={template.rankMedalImage}
                      alt="Honor Medal"
                      className="w-full h-auto drop-shadow-md object-contain"
                    />
                    {student.rank && (
                      <span
                        className="absolute font-moul font-bold drop-shadow"
                        style={{
                          top: '40%',
                          transform: 'translateY(-50%)',
                          fontFamily: getFontFamilyCss(styles.rankMedalText?.font || 'Khmer OS Muol Light'),
                          fontSize: `${styles.rankMedalText?.size || 34}px`,
                          color: styles.rankMedalText?.color || '#ff0000',
                        }}
                      >
                        {student.rank}
                      </span>
                    )}
                  </div>
                ) : (
                  <div className="w-20 h-20 rounded-full border-4 border-amber-400 bg-amber-50 shadow-md flex items-center justify-center font-moul font-bold text-amber-700 text-2xl">
                    {student.rank || '១'}
                  </div>
                )}
              </div>
            )}

            {/* Optional Student Photo */}
            {template.studentPhoto && (
              <div
                className="absolute pointer-events-none select-none overflow-hidden border-2 border-amber-500 shadow-md bg-white"
                style={{
                  top: `calc(32% + ${styles.studentPhoto?.offsetY || 0}px)`,
                  right: `calc(8% + ${styles.studentPhoto?.offsetX || 0}px)`,
                  width: `${styles.studentPhoto?.width || 90}px`,
                  height: `${(styles.studentPhoto?.width || 90) * 1.25}px`,
                  borderRadius: styles.studentPhoto?.shape === 'round' ? '9999px' : '4px',
                  zIndex: 15,
                }}
              >
                <img
                  src={template.studentPhoto}
                  alt={student.name}
                  className="w-full h-full object-cover"
                />
              </div>
            )}

            {/* BOTTOM SECTION: Date & Signatures & QR Code */}
            <div
              className="w-full flex justify-between items-end relative"
              style={{
                fontFamily: getFontFamilyCss(styles.signature?.font || 'Khmer OS Muol Light'),
                transform: `translate(${styles.signature?.offsetX || 0}px, ${styles.signature?.offsetY || 0}px)`,
              }}
            >
              {/* Left Column: Left Signature Block & / or Bottom-Left QR Code */}
              <div className="flex items-end gap-3 min-w-[200px]">
                {/* Left Signature Block (Optional) */}
                {template.showLeftSign && (
                  <div
                    className="text-center"
                    style={{
                      minWidth: '200px',
                    }}
                  >
                    <div
                      className="font-moul mb-1 font-semibold"
                      style={{
                        fontSize: `${(styles.signature?.size || 20) * 0.9}px`,
                        color: styles.signature?.color || '#000000',
                      }}
                    >
                      {template.signTitleLeft}
                    </div>
                    <div
                      className="font-moul text-sm text-slate-700"
                      style={{
                        fontSize: `${(styles.signature?.size || 20) * 0.85}px`,
                      }}
                    >
                      {template.signRoleLeft}
                    </div>
                    {/* Spacer for physical hand signature */}
                    <div className="h-16 w-full flex items-center justify-center" />
                    {template.signNameLeft && (
                      <div
                        className="font-moul font-bold"
                        style={{ fontSize: `${(styles.signature?.size || 20) * 0.85}px` }}
                      >
                        {template.signNameLeft}
                      </div>
                    )}
                  </div>
                )}

                {/* Bottom-Left Unique Student QR Code */}
                {(template.showQrCode ?? true) && (template.qrCodePosition ?? 'bottom-left') === 'bottom-left' && (
                  <div
                    className="flex flex-col items-center bg-white/95 p-1.5 rounded-lg border border-amber-300/80 shadow-2xs select-none backdrop-blur-xs"
                    style={{
                      transform: `translate(${styles.qrCode?.offsetX || 0}px, ${styles.qrCode?.offsetY || 0}px)`,
                    }}
                    title={`QR Code ផ្ទៀងផ្ទាត់សិស្ស: ${student.name} (ID: ${student.id})`}
                  >
                    <StudentQRCode
                      value={qrPayload}
                      size={styles.qrCode?.size || 76}
                      color={styles.qrCode?.color || '#1e293b'}
                    />
                    {(template.showQrCodeLabel ?? true) && (
                      <span
                        className="font-battambang text-[9px] text-slate-700 tracking-tight mt-1 font-semibold text-center leading-none"
                        style={{ fontFamily: getFontFamilyCss('Khmer OS Battambang') }}
                      >
                        {template.qrCodeLabel || 'ស្កេនផ្ទៀងផ្ទាត់'}
                      </span>
                    )}
                  </div>
                )}
              </div>

              {/* Bottom-Center Unique Student QR Code */}
              {(template.showQrCode ?? true) && template.qrCodePosition === 'bottom-center' && (
                <div
                  className="absolute left-1/2 -translate-x-1/2 bottom-0 flex flex-col items-center bg-white/95 p-1.5 rounded-lg border border-amber-300/80 shadow-2xs select-none z-20"
                  style={{
                    transform: `translateX(-50%) translate(${styles.qrCode?.offsetX || 0}px, ${styles.qrCode?.offsetY || 0}px)`,
                  }}
                  title={`QR Code ផ្ទៀងផ្ទាត់សិស្ស: ${student.name} (ID: ${student.id})`}
                >
                  <StudentQRCode
                    value={qrPayload}
                    size={styles.qrCode?.size || 76}
                    color={styles.qrCode?.color || '#1e293b'}
                  />
                  {(template.showQrCodeLabel ?? true) && (
                    <span
                      className="font-battambang text-[9px] text-slate-700 tracking-tight mt-1 font-semibold text-center leading-none"
                      style={{ fontFamily: getFontFamilyCss('Khmer OS Battambang') }}
                    >
                      {template.qrCodeLabel || 'ស្កេនផ្ទៀងផ្ទាត់'}
                    </span>
                  )}
                </div>
              )}

              {/* Right Column: Signature Block & / or Bottom-Right QR Code */}
              <div className="flex items-end gap-3 relative">
                {/* Bottom-Right Unique Student QR Code */}
                {(template.showQrCode ?? true) && template.qrCodePosition === 'bottom-right' && (
                  <div
                    className="flex flex-col items-center bg-white/95 p-1.5 rounded-lg border border-amber-300/80 shadow-2xs select-none backdrop-blur-xs mr-2 mb-1"
                    style={{
                      transform: `translate(${styles.qrCode?.offsetX || 0}px, ${styles.qrCode?.offsetY || 0}px)`,
                    }}
                    title={`QR Code ផ្ទៀងផ្ទាត់សិស្ស: ${student.name} (ID: ${student.id})`}
                  >
                    <StudentQRCode
                      value={qrPayload}
                      size={styles.qrCode?.size || 76}
                      color={styles.qrCode?.color || '#1e293b'}
                    />
                    {(template.showQrCodeLabel ?? true) && (
                      <span
                        className="font-battambang text-[9px] text-slate-700 tracking-tight mt-1 font-semibold text-center leading-none"
                        style={{ fontFamily: getFontFamilyCss('Khmer OS Battambang') }}
                      >
                        {template.qrCodeLabel || 'ស្កេនផ្ទៀងផ្ទាត់'}
                      </span>
                    )}
                  </div>
                )}

                {/* Right Signature Block with Date/Place & Stamp */}
                <div
                  className="text-center relative"
                  style={{
                    minWidth: '320px',
                    visibility: template.showRightSign ? 'visible' : 'hidden',
                  }}
                >
                  {/* Date & Place */}
                  <div
                    className="font-battambang leading-relaxed text-slate-800 text-xs sm:text-sm mb-2 text-left w-full"
                    style={{
                      fontFamily: getFontFamilyCss(styles.date?.font || 'Khmer OS Battambang'),
                      fontSize: `${styles.date?.size || Math.max(13, (styles.body?.size || 20) * 0.68)}px`,
                      color: styles.date?.color || '#1e293b',
                      textAlign: (styles.date?.align || 'left') as any,
                      transform: `translate(${styles.date?.offsetX || 0}px, ${styles.date?.offsetY || 0}px)`,
                    }}
                  >
                    {datePlaceLines.map((line, i) => (
                      <div
                        key={i}
                        className="py-0.5"
                        style={{ textAlign: (styles.date?.align || 'left') as any }}
                      >
                        {line}
                      </div>
                    ))}
                  </div>

                  {/* Signatory Role: នាយកសាលា */}
                  <div
                    className="font-moul font-bold"
                    style={{
                      fontSize: `${styles.signature?.size || 20}px`,
                      color: styles.signature?.color || '#000000',
                    }}
                  >
                    {template.signRoleRight}
                  </div>

                  {/* Hand Signature space & Stamp Overlay */}
                  <div className="h-20 w-full relative flex items-center justify-center">
                    {template.showStamp && template.stampImage && (
                      <div
                        className="absolute pointer-events-none select-none"
                        style={{
                          width: `${styles.stamp?.width || 120}px`,
                          top: `calc(10% + ${styles.stamp?.offsetY || 0}px)`,
                          left: `calc(35% + ${styles.stamp?.offsetX || 0}px)`,
                          transform: `rotate(${styles.stamp?.rotation || -8}deg)`,
                          opacity: styles.stamp?.opacity ?? 0.85,
                          zIndex: 25,
                        }}
                      >
                        <img
                          src={template.stampImage}
                          alt="Official Stamp"
                          className="w-full h-auto drop-shadow-sm mix-blend-multiply"
                        />
                      </div>
                    )}
                  </div>

                  {/* Signatory Name */}
                  {template.signNameRight && (
                    <div
                      className="font-moul font-bold"
                      style={{ fontSize: `${(styles.signature?.size || 20) * 0.9}px` }}
                    >
                      {template.signNameRight}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
);

CertificatePreview.displayName = 'CertificatePreview';
