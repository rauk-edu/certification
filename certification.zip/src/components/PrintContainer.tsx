import React from 'react';
import { CertificateConfig, StudentData } from '../types/certificate';
import { CertificatePreview } from './CertificatePreview';

interface PrintContainerProps {
  config: CertificateConfig;
  students: StudentData[];
  printMode: 'current' | 'all';
  activeStudentIndex: number;
}

export const PrintContainer: React.FC<PrintContainerProps> = ({
  config,
  students,
  printMode,
  activeStudentIndex,
}) => {
  const studentsToPrint =
    printMode === 'current'
      ? [students[activeStudentIndex] || students[0]]
      : students;

  return (
    <div className="print-only">
      {studentsToPrint.map((student, idx) => (
        <div key={student.id || idx} className="print-page-wrapper">
          <div className="print-cert-scaler">
            <CertificatePreview
              config={config}
              student={student}
              studentIndex={printMode === 'current' ? activeStudentIndex : idx}
              scale={1}
              isPrintVersion={true}
            />
          </div>
        </div>
      ))}
    </div>
  );
};
